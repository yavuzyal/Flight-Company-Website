<?php

session_start();

include_once "config.php";
include ("dbAddFlight.php");
include ("adddiscount.php");
include ("changedate.php");
include ("deleteflight.php");
//include ("viewSales2.php");
//include ("updatePhoneNumber.php");

if (!isset($_SESSION['admin']))
{
  echo 
  "<div class='modal' id='myModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
              <h5 class='modal-title text-center'>You are not allowed here.</h5>
              <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
              </button>
            </div>
            <div class='modal-body'>
              <p>You are being redirected to main page.</p>
            </div>
            <div class='modal-footer'>
              <button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
            </div>
        </div>
      </div>
  </div>";
}

else {
  $admin = $_SESSION["admin"];
  $sql_statement = "SELECT * FROM admins WHERE admin_id = '$admin'";
  $result = mysqli_query($db, $sql_statement);
  $row = mysqli_fetch_assoc($result);
  $name_surname = $row['admin_id'];
}

?>

<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Admin Panel</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="profile.css" >

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</head>

<body>
  <?php 
  if (isset($result_add))
  {
    echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $result_add . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }

  if (isset($update_phone_result))
  {
    echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $update_phone_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  
  if(isset($search_error)) 
  {
	echo "<div class='alert alert-danger mb-0' id='MyPopup' role='alert'>" . $search_error . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  if(isset($date_error)) 
  {
	echo "<div class='alert alert-danger mb-0' id='MyPopup' role='alert'>" . $date_error . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  if(isset($date_result)) 
  {
  echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $date_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  if(isset($discount_result)) 
  {
  echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $discount_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  if(isset($_GET['msg'])) 
  {
    if ($_GET['msg'] == "Request is accepted." or $_GET['msg'] == "Request is denied.")
    {
      echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . urldecode($_GET['msg']) . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
    }
    else
    {
        echo "<div class='alert alert-danger mb-0' id='MyPopup' role='alert'>" . urldecode($_GET['msg']) . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
    }
  }
  if (isset($delete_result))
  {
    if ($delete_result == "Flight is deleted successfully.") 
    {
      echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $delete_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
    }
    else {
      echo "<div class='alert alert-danger mb-0' id='MyPopup' role='alert'>" . $delete_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
    }
  }
  ?>
  <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-dark bg-primary border-bottom">
        <a class="navbar-brand ml-2" href="main.php">IDK Airlines</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item">
              <span class="navbar-text"> <?php if(isset($_SESSION["admin"])) echo $_SESSION["admin"]; ?></span>
                <div class="btn-group">
                  <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="far fa-user fa-lg"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-right">
                    <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
                  </div>
                </div> 
            </li>
          </ul>
        </div>
      </nav>
    </div>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-outline-primary border-right" id="sidebar-wrapper">
      <div class="media mt-4 mb-5 ml-3">
          <span class="media-left">
              <i class="far fa-user fa-5x"></i>
          </span>
          <div class="media-body ml-3">
              <p><?php if(isset($_SESSION["admin"])) echo "$name_surname" ?></p>
          </div>
      </div>
      <div class="list-group list-group-flush">
        <a href="admin_panel.php?view=addFlight" class="list-group-item list-group-item-action bg-light">Add Flight</a>
        <a href="admin_panel.php?view=viewSales" class="list-group-item list-group-item-action bg-light">View Sales</a>
        <a href="admin_panel.php?view=search" class="list-group-item list-group-item-action bg-light">Flight Operations</a>
        <a href="admin_panel.php?view=refundrequests" class="list-group-item list-group-item-action bg-light">Refund Requests</a>
        <a href="logout.php" class="list-group-item list-group-item-action bg-light">Logout</a>

      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <div class="container-fluid">
        <div class="row">   
          <?php if (isset($_GET["view"]) && $_GET["view"] == "addFlight"): ?>
            <div class="col-lg-12 ml-sm-auto ml-md-3 px-md-3 mt-4">
              <h2 class="display-4" style="margin-left: 0rem; font-size: 2.5rem;">Add Flight</h2>
                <form action="admin_panel.php?view=addFlight" id="addFlightForm" method = "POST">
                	<input type="hidden" name="hiddenAdd" id="hiddenAdd">
                	<div class="form row">
	                    <div class="form-group col-md-5">
	                      <label for="f_id" class="col-form-label">Enter Flight ID</label>
	                        <input type="number" class="form-control" name="f_id" id="f_id" required>
	                    </div>
                  </div>

	                <?php
	                $sql_airport_ids = "SELECT airport_id FROM airports";
	                $myresult = mysqli_query($db, $sql_airport_ids);
	                ?>

                  	<div class="form row">
                  		<div class="form-group col-md-5">
                  			<label for="from_add_text" class="col-form-label">Select departure airport</label>
	                  		<div class="input-group">
	                  			<input type="text" class="form-control" id="from_add_text" name="from_add_text" placeholder="Departure Airport">
	                  			<div class="input-group-append">
	                    			<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
				                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
					                    <?php                   
					                  	while($id_rows = mysqli_fetch_assoc($myresult))
					                  	{
					                    	$id = $id_rows['airport_id'];
					                    	echo "<li class='dropdown-item' id='from_add'>" . $id . "</li>"; 
					                  	}
					                  	?>
	                  				</ul>
	                  			</div>
	                  		</div>
                		</div>
                	</div>

	                <?php
	                  $sql_airport_ids = "SELECT airport_id FROM airports";
	                  $myresult = mysqli_query($db, $sql_airport_ids);
	                ?>

                    <div class="form row">
                    	<div class="form-group col-md-5">
                    		<label for="to_add_text" class="col-form-label">Select arrival airport</label>
	                  	   	<div class="input-group"> 
	                  	  	    <input type="text" class="form-control" id="to_add_text" name="to_add_text" placeholder="Arrival Airport">
	                  	        <div class="input-group-append">
	                    	      	<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
	                  				<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
	                      			<?php                   
	                  					while($id_rows = mysqli_fetch_assoc($myresult))
	                  					{
						                    $id = $id_rows['airport_id'];
						                    echo "<li class='dropdown-item' id='to_add'>" . $id . "</li>"; 
	                  					}
	                  				?>
	                  				</ul>
	                  			</div>
	                  		</div>
	                  	</div>
                	</div>
                	<div id="airportConfirm" class="text-danger mt-n2" style="display: none;">
                    	Departure and arrival airports cannot be same.
                  	</div>                  

                	<div class="form row">
                		<div class="form-group col-md-5">
                			<label for="f_date" class="col-form-label">Date</label>
	                		<div class="input-group">
	                  			<input type="datetime-local" class="form-control" id="f_date" name="f_date" required>
	                		</div>
                		</div>
                	</div>
                	<div id="dateConfirm" class="text-danger mt-n2" style="display: none;">
                    	Flight date cannot be selected from the past.
                  	</div> 
                  
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="f_id" class="col-form-label">Price</label>
                      <input type="number" class="form-control" name="f_price" id="f_id" required>
                    </div>
                  </div>

                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="f_aircraft" class="col-form-label">Enter Aircraft ID</label>
                      <input type="number" class="form-control" name="f_aircraft" id="f_aircraft" required>
                    </div>
                  </div>

                  <?php if (isset($add_error)): ?>
                  	<div class="text-danger mb-2" id="addError"><?php echo $add_error; ?></div>
                  <?php endif; ?>

                  <button class="btn btn-primary mt-2" type="button" id="button_add">Add</button>
                </form>
            </div>
                
            
            <?php elseif (isset($_GET["view"]) && $_GET["view"] == "viewSales"): ?>
            	<div class="col-lg-12 ml-sm-auto px-md-3 mt-4">
            		<h2 class="display-4 ml-3" style="font-size: 2.5rem;">Sales</h2>
  	                <form action = "admin_panel.php?view=viewSales" method = 'POST'>
	                	<div class="form row ml-sm-auto">
	                		<div class="col-md-3 mt-2">
	                			<label for="start_date" class="col-form-label">Starting Date: </label>
	                			<input type="datetime-local" class="form-control" id="start_date" name="start_date" required>
	                		</div>
	                		<div class="col-md-3 mt-2">
	                			<label for="end_date" class="col-form-label">Ending Date: </label>
	                			<input type="datetime-local" class="form-control" id="end_date" name="end_date" required>
	                		</div>
	                		<div class="col-md-3" style="margin-top: 2.85rem;">
	                			 <button class="btn btn-primary" name = "buton" type = "submit"> View Sales </button>
	                		</div>
	                	</div>             
	                </form> 
            	</div>

            <?php if (isset($_POST["start_date"]) && isset($_POST["end_date"])): ?>
                <div class="col-md-11 ml-sm-auto px-md-3 mt-5">           
                <div align="center">

                  <table class="table table-striped" style="margin-left: -10rem;"> <!-- table-striped -->
                    <thead>
                  <tr> <th> From </th> <th> To </th> <th class="pl-5"> Date </th> <th> Price </th> <th> Ticket Type </th> </tr> 
                    </thead>
                  <?php

                  include "config.php";

                  $start = $_POST['start_date'];
                  $end = $_POST['end_date'];
                  $count = 0;

                  $sql_tickets = "SELECT * FROM tickets";

                  $result = mysqli_query($db, $sql_tickets);

                  while($row = mysqli_fetch_assoc($result))
                  {
                    $ticket_price = $row['ticket_price'];
                    $status = $row['ticket_status'];
                    $flight_id = $row['flight_id'];

                    $sql_flights_intime = "SELECT * FROM flights WHERE flight_id = \"$flight_id\"";
                    $flight_result = mysqli_query($db, $sql_flights_intime);

                    $flight_row_time = mysqli_fetch_assoc($flight_result);

                    $dep_airport = $flight_row_time['flight_dep_airport'];
                    $arr_airport = $flight_row_time['flight_arr_airport'];
                    $date = $flight_row_time['flight_date'];
                    $f_price = $flight_row_time['flight_price'];

                    if ($date > $start and $date < $end)
                    {

                      echo "<tr>" . "<td>" . $dep_airport . "</td>" . "<td>" . $arr_airport . "</td>" . "<td>" . $date . "</td>" . "<td>" . ($ticket_price + $f_price) . " TL" . "</td>" . "<td>" . $status . "</td>" . "</tr>";
                      $count++;
                    }
                  }

                    echo "<font size = \"+2\" style='margin-left: -15rem;'> Total Number of Saled Tickets: $count</font><br>" . "<br>";

                  ?>

                  </table>
                 
                  </div>

            </div>

            <?php endif; ?>    

            <?php elseif (isset($_GET["view"]) && $_GET["view"] == "search"): ?>
            </div>
            <div class="row">      
	            <div class="col-md-10 ml-sm-auto ml-md-4 mt-5 mx-auto" >
	            	<h2 class="display-4 text-center" style="margin-left: 0rem; font-size: 2.5rem;">Flight Operations</h2><br>
	                <form action = "admin_panel.php?view=search" method = 'POST'>
		                <?php
		                	$sql_airport_ids = "SELECT airport_id FROM airports";
		                  	$myresult = mysqli_query($db, $sql_airport_ids);
		                ?>
		               	<div class="form row justify-content-center">
		               		<div class="form-group col-md-6">
		               			<label for="from_search_text" class="col-form-label">Select Departure Airport</label> 
			                	<div class="input-group">
			                		<input type="text" class="form-control" id="from_search_text" name="from_search_text" 
			                		placeholder="Departure Airport" required>
			                  		<div class="input-group-append">
			                  			<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
					                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
					                    <?php                   
							                while($id_rows = mysqli_fetch_assoc($myresult))
							                {
							                  $id = $id_rows['airport_id'];
							                  echo "<li class='dropdown-item' id='from_search'>" . $id . "</li>"; 
							                }
						                ?> 
					                    </ul>                 
			                 		 </div>
			                  	</div>
			                </div>
		                </div>

		                <?php
		                	$sql_airport_ids = "SELECT airport_id FROM airports";
		                  	$myresult = mysqli_query($db, $sql_airport_ids);
		                ?>

		                <div class="form row justify-content-center">
		                	<div class="form-group col-md-6">
		                		<label for="to_search_text" class="col-form-label">Select Arrival Airport</label>
			                	<div class="input-group">			                		
			                		<input type="text" class="form-control" id="to_search_text" name="to_search_text" 
			                		placeholder="Arrival Airport" required> 
			                  		<div class="input-group-append">
				                    	<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>

				                  		<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
				                      	<?php                   
				                  			while($id_rows = mysqli_fetch_assoc($myresult))
				                  			{
							                    $id = $id_rows['airport_id'];
							                    echo "<li class='dropdown-item' id='to_search'>" . $id . "</li>"; 
				                  			}
				                  		?>
				                  		</ul>
			                  		</div>            
			                  	</div>
			                </div>
		                </div>

		                <div class="form row justify-content-center">
		                	<div class="form-group col-md-3">
			                	<label for="start_date2">Starting Date: </label>
		                  		<input type="datetime-local" class="form-control" id="start_date2" name="start_date2" required>
			                </div>
			                <div class="form-group col-md-3">
			                	<label for="end_date2">Ending Date: </label>
		                  		<input type="datetime-local" class="form-control" id="end_date2" name="end_date2" required>
			                </div>
		                </div>
		                <div class="form row justify-content-center">
		                	<div class="form-group col-md-1">
		                		<button class="btn btn-primary"type="submit"> Search </button>
		                	</div>
		                </div>
	                	
	            	</form> 
	            </div>
	        </div>

          <?php if (isset($_POST["from_search_text"]) && isset($_POST["to_search_text"])): ?>
            <div class="col-md-11 ml-sm-auto px-md-3 mt-5">
                <table class="table table-striped mt-5 ml-n5 " style="margin-left: -10rem;">
	            	<thead>
	                	<tr> <th> ID </th> <th > From </th> <th > To </th> <th > Date </th> <th > Discount Ratio (%) </th> <th > Price </th> <th > Remaining Seats </th> <th > Popularity </th> <th > Aircraft ID </th><th > Views </th></tr> 
	                </thead>

                  	<tbody>
                	<?php
	                  $search_from = $_POST['from_search_text'];
	                  $search_to = $_POST['to_search_text'];
	                  $search_start = $_POST['start_date2'];
	                  $search_end = $_POST['end_date2'];

	                  $id_array = array();
	                  $id_array2 = array();
	                  $id_array3 = array();

	                  $sql_flights = "SELECT * FROM flights";

	                  $result = mysqli_query($db, $sql_flights);

	                  while($row = mysqli_fetch_assoc($result))
	                  {
	                    $f_id = $row['flight_id'];
	                    $f_from = $row['flight_dep_airport'];
	                    $f_to = $row['flight_arr_airport'];
	                    $f_date = $row['flight_date'];
	                    $f_disc = $row['flight_discratio'];
	                    $f_price = $row['flight_price'];
	                    $f_remaining = $row['flight_remainingseats'];
	                    $f_pop = $row['flight_popularity'];
	                    $f_aircraft = $row['flight_aircraft'];
	                    $f_view = $row['flight_view'];

	                    if ($search_from == $f_from and $search_to == $f_to and $search_start <= $f_date and $search_end >= $f_date)
	                    {
	                      echo "<tr>" . "<td>" . $f_id . "</td>" . "<td>" . $f_from . "</td>" . "<td >" . $f_to . "</td>" . "<td>" . $f_date . "</td>" . "<td >" . $f_disc . "</td>" . "<td >" . $f_price . "</td>" . "<td >" . $f_remaining . "</td>" . "<td >" . $f_pop . "</td>" . "<td >" . $f_aircraft . "</td>" . "<td >" . $f_view . "</td>" . "</tr>";
	                      array_push($id_array, $f_id);
	                      array_push($id_array2, $f_id);
	                      array_push($id_array3, $f_id);
	                    }
	                  }
              		?>
                  </tbody>
            	</table>
                 

                <form action="admin_panel.php?view=search" method="POST">
                    <label for = "f_id"> Flight ID: </label>
                    <select name="f_id" required>

                    <?php
                    while ($var = array_pop($id_array))
                    {
                      echo "<option value=$var>".$var."</option>";
                    }
                    ?>
                    </select>

                    <label for="discratio">Discount Ratio:  </label>
                    <input type="number" id="discratio" name="discratio" required min = 0 max = 100>

                    <button class="btn btn-primary" type="submit"> Add Discount </button>
                </form> 

                  <form action="admin_panel.php?view=search" method="POST">
                    <label for = "f_id2"> Flight ID: </label>
                    <select name="f_id2" required>

                    <?php
                    while ($var = array_pop($id_array2))
                    {
                      echo "<option value=$var>".$var."</option>";
                    }
                    ?>
                    </select>
                    <button class="btn btn-primary"type="submit"> Delete </button>
                  </form>

                  <form action="admin_panel.php?view=search" method="POST">
                    <label for = "f_id3"> Flight ID: </label>
                    <select name="f_id3" required>

                    <?php
                    while ($var = array_pop($id_array3))
                    {
                      echo "<option value=$var>".$var."</option>";
                    }
                    ?>
                    </select>

                    <label for="newDate">New Date: </label>
                    <input type="datetime-local" id="newDate" name="newDate" required >
                    
                    <button class="btn btn-primary"type="submit"> Update Date </button>
                  </form> 

                  <?php endif; ?>

                  

              <?php elseif (isset($_GET["view"]) && $_GET["view"] == "refundrequests"): ?>
            <div class="col-md-11 ml-sm-auto px-md-3 mt-5">
              <h2 class="display-4 ml-n5" style="font-size: 2.5rem;">Refund Requests</h2>
              <table class="table table-striped mt-5 ml-n5 " style="margin-left: -20rem;">
                <thead>
                    <tr> <th> User ID </th> <th > Flight ID </th> <th> Seat Number </th><th> Actions </th></tr> 
                  </thead>

                    <tbody>
                  <?php

                    $sql_refunds = "SELECT * FROM refunds";

                    $result = mysqli_query($db, $sql_refunds);

                    if($result){
                      while($row = mysqli_fetch_assoc($result))
                      {
                      $r_user_id = $row['user_id'];
                      $r_flight_id = $row['flight_id'];
                      $r_seat_no = $row['seat_no'];
                     
                      echo "<tr>" . "<td>" . $r_user_id . "</td>" . "<td>" . $r_flight_id . "</td>" . "<td>" . $r_seat_no . "</td>" . "<td>" . "<a type='button' class='btn btn-success' href='refundDbUpdate.php?r=accept&u_id=" . $r_user_id . "&f_id=" . $r_flight_id . "&seat=" . $r_seat_no . "'><i class='fas fa-edit'></i></a>" . "<a type='button' class='btn btn-danger ml-2' href = 'refundDbUpdate.php?r=reject&u_id=" . $r_user_id . "&f_id=" . $r_flight_id . "&seat=" . $r_seat_no . "'><i class='far fa-trash-alt'></i></a>" . "</td>" . "</tr>";
                      }
                  }       
                  ?>
                  </tbody>
              </table>
        </div>
        <?php endif; ?>
      </div>
        </div>
      </div>
  </div>

  <script src="js/profile.js"></script>

  <script type="text/javascript"> 

    $( "#from_add.dropdown-item" ).click(function() {
    	var value = $(this).text();
  		$("#from_add_text").val(value); //text kutusunun id departure yerine
 	});

	$( "#to_add.dropdown-item" ).click(function() {
	    var value = $(this).text();
	    $("#to_add_text").val(value);
	});

	$( "#from_search.dropdown-item" ).click(function() {
	      var value = $(this).text();
	      $("#from_search_text").val(value); //text kutusunun id departure yerine
	      });

	$( "#to_search.dropdown-item" ).click(function() {
	    var value = $(this).text();
	    $("#to_search_text").val(value);
	});

	$("#button_add").click(function() {
		var currentDate = new Date();
		const currentDateParsed = Date.parse(currentDate);
		const enteredDateParsed = Date.parse($("#f_date").val());


		if ($("#from_add_text").val() == $("#to_add_text").val())
		{		
			$("#dateConfirm").hide();
			$("#addError").hide();
			$("#f_date").removeClass("is-invalid");
			$("#from_add_text").addClass("is-invalid");
			$("#to_add_text").addClass("is-invalid");
			$("#airportConfirm").show();
		}

		else if (enteredDateParsed <= currentDateParsed)
		{
			$("#airportConfirm").hide();
			$("#addError").hide();
			$("#from_add_text").removeClass("is-invalid");
			$("#to_add_text").removeClass("is-invalid");
			$("#f_date").addClass("is-invalid");
			$("#dateConfirm").show();
		}

		else {
			$("#hiddenAdd").val("1");
			$("#addFlightForm").submit();
		}
	});

   </script>

</body>
</html>
