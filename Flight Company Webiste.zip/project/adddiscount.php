<?php  

include_once "config.php";

if (isset($_POST["discratio"]) && isset($_POST["f_id"]))
{
  $id = $_POST['f_id'];
  $ratio = $_POST['discratio'];
  $current_date = date('Y-m-d H:i:s');

  $sql_f_date = "SELECT flight_date FROM flights WHERE flight_id = '$id'";
  $result = mysqli_query($db, $sql_f_date);
  $row = mysqli_fetch_assoc($result);
  $flight_date = $row['flight_date'];

  if ($current_date <= $flight_date)
  {
    $sql_discount = "UPDATE flights SET flight_discratio = '$ratio' WHERE flight_id = '$id'";

    if (!mysqli_query($db, $sql_discount))
    {
      $search_error = "An unexpected error has occurred!";
    }
    else {
      $discount_result = "Discount is added to the selected flight.";
    }
  }
  else
  {
    $search_error = "You cannot make discount on this flight!";
  }
}

?>