<?php 

session_start();

include "config.php";

if (isset($_SESSION['admin']) and isset($_GET['r']))
{
	$response = $_GET['r'];
	$user_id = $_GET['u_id'];
	$flight_id = $_GET['f_id'];
	$seat_no = $_GET['seat'];

	if ($response == 'accept')
	{
		$sql_dpoint = "SELECT * FROM tickets WHERE ticket_seatno = '$seat_no' and user_id = '$user_id' and flight_id = '$flight_id'";
		$res_dpoint = mysqli_query($db, $sql_dpoint);
		$row_dpoint = mysqli_fetch_assoc($res_dpoint);
		$d_points = $row_dpoint["ticket_price"] / 100; // discount points that will be taken
		
		$sql_ticket = "DELETE FROM tickets WHERE ticket_seatno = '$seat_no' and user_id = '$user_id' and flight_id = '$flight_id'";
		$sql_refund = "DELETE FROM refunds WHERE seat_no = '$seat_no' and user_id = '$user_id' and flight_id = '$flight_id'";

		$res_refunds = mysqli_query($db, $sql_refund);
		$res_tickets = mysqli_query($db, $sql_ticket);

		if ($res_refunds and $res_tickets)
		{
			$sql_currdpoint = "SELECT * FROM users WHERE user_id = '$user_id'";
			$res_currdpoint = mysqli_query($db, $sql_currdpoint);
			$row_currdpoint = mysqli_fetch_assoc($res_currdpoint);
			$curr_dpoints = $row_currdpoint["user_discpoint"];

			if ($curr_dpoints >= $d_points)
			{
				$sql_update_dpoint = "UPDATE users SET user_discpoint = user_discpoint - '$d_points' WHERE user_id = '$user_id'";
				$res_update = mysqli_query($db, $sql_update_dpoint);

				if ($res_update)
				{
					$final_decision = "Request is accepted.";
				}
				else {
					$final_decision = "An unexpected error occurred!";
				}		
			}
			else {
				$sql_update_dpoint = "UPDATE users SET user_discpoint = 0 WHERE user_id = '$user_id'";
				$res_update = mysqli_query($db, $sql_update_dpoint);
				if ($res_update)
				{
					$final_decision = "Request is accepted.";
				}
				else {
					$final_decision = "An unexpected error occurred!";
				}	
			}		
		}
		else
		{
			$final_decision = "An unexpected error occurred!";
		}
	}
	elseif ($response == 'reject')
	{
		$sql_refund = "DELETE FROM refunds WHERE seat_no = '$seat_no' and user_id = '$user_id' and flight_id = '$flight_id'";

		$res_refunds = mysqli_query($db, $sql_refund);

		if ($res_refunds)
		{
			$final_decision = "Request is denied.";
		}
		else
		{
			$final_decision = "An unexpected error occurred!";
		}

	}
	else
	{
		$final_decision = "You are allowed here! Something went wrong.";
	}
}

header("Location: admin_panel.php?view=refundrequests&msg=" . urlencode($final_decision));

?>