<?php 

// Start the session
session_start();

include_once "config.php";
include('useraddition.php');


if (isset($_SESSION['user']) || isset($_SESSION['admin']))
{
  echo 
  "<div class='modal' id='myModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
              <h5 class='modal-title text-center'>You are not allowed here.</h5>
              <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
              </button>
            </div>
            <div class='modal-body'>
              <p>You are being redirected to main page.</p>
            </div>
            <div class='modal-footer'>
              <button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
            </div>
        </div>
      </div>
  </div>";
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="signup.css">	
	<title>Sign Up!</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar navbar-dark bg-primary">
	  <a class="navbar-brand" href="main.php">IDK Airlines</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="userActions">
	    <ul class="navbar-nav ml-auto">
	      <li class="nav-item">
	        <a class="nav-link" href="login.php">Login
	        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
			  <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
			</svg>
	        <span class="sr-only">(current)</span></a>
	      </li>
	    </ul>
	  </div>
	</nav>

	<div class="container">
		<h2 class="display-5">Sign up for free!</h2>
		<p class="lead">
 		 Join our family and enjoy the cheapest flights you can ever find!
		</p>

		<form action="signup.php" method="POST">
  			<div class="form row">
  				<div class="form-group col-md-8">
    				<label for="inputName" class="col-sm-2 col-form-label">Name</label>
    				<div class="col-sm-10">
      					<input type="text" class="form-control" name="name" id="inputName" required>
    				</div>
  				</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8">
	    			<label for="inputSurname" class="col-sm-2 col-form-label">Surname</label>
	    			<div class="col-sm-10">
	      				<input type="text" class="form-control" name="surname" id="inputSurname" required>
	    			</div>
    			</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8">
	    			<label for="inputUsername" class="col-sm-2 col-form-label">Username</label>
	    			<div class="col-sm-10">
	      				
	      				<?php if (isset($name_error)): ?>
	      				<input type="text" class="form-control is-invalid" name="username" id="inputUsername" value="<?php echo $username; ?>" required>
	  					<div id="usernameValidation" class="text-danger">
        					<?php echo $name_error; ?>
      					</div>
      					<?php else: ?>
      						<input type="text" class="form-control" name="username" id="inputUsername" value="<?php echo $username; ?>" required>
	  					<?php endif; ?>
	    			</div>
    			</div>
  			</div>		
  			<div class="form row">
  				<div class="form-group col-md-8">
	    			<label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
	    			<div class="col-sm-10">
	      				<input type="password" class="form-control" name="pass" id="inputPassword" 
	      				 pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
 						 title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters"
 						 required>
	    			</div>
    			</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8">
	    			<label for="inputTelephone" class="col-sm-8 col-form-label">Telephone Number</label>
	    			<div class="col-sm-10">
	      				
	      				<?php if (isset($phone_error)): ?>
	      				<input type="tel" class="form-control is-invalid" name="phoneno" id="inputTelephone" pattern="[+]{1}[0-9]{2,3}[0-9]{10}" required title="Must contain the following form: '+(COUNTRY CODE)XXXXXXXXXX' (don't use paranthesis)" value="<?php echo $phoneno; ?>">
	  					<div id="phoneValidation" class="text-danger">
        					<?php echo $phone_error; ?>
      					</div>
      					<?php else: ?>
      						<input type="tel" class="form-control" name="phoneno" id="inputTelephone" pattern="[+]{1}[0-9]{2,3}[0-9]{10}" required title="Must contain the following form: '+(COUNTRY CODE)XXXXXXXXXX' (don't use paranthesis)" 
      						value="<?php echo $phoneno; ?>">
	  					<?php endif ?>
	    			</div>
    			</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8">
  					<label for="inputQuestion" class="col-sm-8 col-form-label">Security Question</label>
  					<div class="col-sm-10">
		  				<div class="input-group">
							<select class="form-control" id="inputQuestion" name="question">
						     	<option>What was your childhood nickname?</option>
						    	<option>What is the name of your favorite childhood friend?</option>
						    	<option>What street did you live on in third grade?</option>
						    	<option>What is your oldest sibling's middle name?</option>
						    	<option>What school did you attend for sixth grade?</option>
						    	<option>What was the last name of your third grade teacher?</option>
						    	<option>In what city or town was your first job?</option>
						    	<option>Where were you when you first heard about 9/11?</option>
						    	<option>What is the name of the company of your first job?</option>
						    	<option>What is your oldest cousin's first and last name?</option>
						    </select>
						</div>
					</div>
  				</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8">
	    			<label for="inputAnswer" class="col-sm-2 col-form-label">Answer</label>
	    			<div class="col-sm-10">
	      				<input type="text" class="form-control" name="answer" id="inputAnswer" required>
	    			</div>
    			</div>
  			</div>
  			<div class="form row">
  				<div class="form-group col-md-8 mx-1">
		  			<div class="custom-control custom-checkbox">
		  				<input type="checkbox" class="custom-control-input" id="customCheck1" required>
		 			    <label class="custom-control-label" for="customCheck1">I guarantee that the information I have given is correct</label>
					</div>
				</div>
			</div>
			<div class="form row">
				<div class="col-md-2 col-sm-3"></div>
				<div class="form-group col-md-8 col-sm-6 mx-4">
		    		<button type="submit" name="register" class="btn btn-outline-success" id="signup">Sign up!</button>
		    	</div>
		    	<div class="col-md-2 col-sm-3"></div>
		    </div>    
	</div>

	<script type="text/javascript">
		$(document).ready(function() {
    		$('#myModal').modal('show');
		});

		$("#redirectButton").click(function() {
			window.location.href = "main.php";
		});
	</script>
</body>
</html>