<?php

include_once "config.php";

if (isset($_POST['continue']))
{
	$username = $_POST['username'];
	$phoneno = $_POST['phoneno'];
	$question = $_POST['question'];
	$answer = $_POST['answer'];

	echo $username . " " . $phoneno . " " . $question . " " . $answer;

	$stmt = "SELECT * 
			 FROM users U
			 WHERE U.user_id = \"$username\" AND U.user_phone = \"$phoneno\" 
			 AND U.user_question = \"$question\" AND U.user_answer = \"$answer\"";

	$result = mysqli_query($db, $stmt);

	if (mysqli_num_rows($result) <= 0)
		$error = "The information you have provided is wrong! Please try again.";
	else {
		$_SESSION["candidate_user"] = $username;
		header("Location: changepassword.php");
	}
}
?>