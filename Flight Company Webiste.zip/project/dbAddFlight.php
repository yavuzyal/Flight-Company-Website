<?php
include_once "config.php";

if (isset($_POST["hiddenAdd"]))
{
	$flight_id = $_POST['f_id'];
	$dep_air = $_POST['from_add_text'];
	$arr_air = $_POST['to_add_text'];
	$date = date('Y-m-d H:i:s', strtotime($_POST['f_date']));
	$price = $_POST['f_price'];
	$air_id = $_POST['f_aircraft'];

	$sql_add_flight = "INSERT INTO flights VALUES ('$flight_id', 0, '$arr_air', '$dep_air', '$date', 0, '$price', 174 , 0, 
					  '$air_id')";

	if (mysqli_query($db, $sql_add_flight))
	{
  		$result_add = "Flight has been added successfully.";
	}
	else
	{
  		$add_error = "A problem has occurred while adding a new flight.";
	}
}
?>