<?php 

// Start the session
session_start();

if (isset($_GET['msg']))
{
	echo "<div class='alert alert-success' id='MyPopup' role='alert'>" . urldecode($_GET['msg']) . 
	"<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
}

include_once "config.php";

$sql_statement = "SELECT A.airport_city, A.airport_id FROM airports A";

?>

<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
	
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="main.css">
	<title>Main Page</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark">
	  <a class="navbar-brand" href="main.php">IDK Airlines</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="userActions">
	    <ul class="navbar-nav ml-auto">
	    	<?php if (!isset($_SESSION["user"]) && !isset($_SESSION["admin"])): ?>
	    	<li class="nav-item">
		        <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
					  <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
					  <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
					</svg>
		        <span class="sr-only">(current)</span></a>
	    	</li>
	    	<li class="nav-item">
		        <a class="nav-link" style="color: #fff" href="login.php">Login
		        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
				  <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
				</svg>
		        <span class="sr-only">(current)</span></a>
	    	</li>
	    	<?php else: ?>
	    	<li class="nav-item">
	    		<span class="navbar-text">Welcome 
	    		<?php if (isset($_SESSION["user"])): ?> 
	    			<?php echo $_SESSION["user"] ?></span>
	    		<?php elseif (isset($_SESSION["admin"])): ?>
	    			<?php echo $_SESSION["admin"] ?></span>
	    		<?php endif; ?>
		        <div class="btn-group">
				  <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				    <i class="far fa-user fa-lg"></i>
				  </button>
				  <div class="dropdown-menu dropdown-menu-right">
				  	<?php if (isset($_SESSION["user"])): ?> 
				  		<button class="dropdown-item" type="button" id="userProfile">Profile Page</button>
	    			<?php elseif (isset($_SESSION["admin"])): ?>
	    				<button class="dropdown-item" type="button" id="adminPanel">Admin Panel</button>
	    			<?php endif; ?>
				    <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
				  </div>
				</div> 
	    	</li>	
	    	<?php endif ?>
	    </ul>
	  </div>
	</nav>

	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div id="content">
					<p>Fly with the cheapest prices!<p>
					<button class="btn btn-light btn-lg" data-toggle="collapse" data-target="#collapseSearch" 
					aria-expanded="false" aria-controls="collapseSearch">Get Started</button>
				</div>
			</div>
		</div>
		<div class="collapse" id="collapseSearch">
			<div class="card card-body">
				<form action="searchresult.php" method="POST" id="search">
				  	<div class="form-row">
					    <div class="form-group col-md-6">
		      				<div class="input-group mb-3">
			  					<input type="text" class="form-control" placeholder="Departure Airport" aria-label="Departure Airport"
			  					aria-describedby="button-addon2" id="departure" name="departure_airport">
			  					<div class="input-group-append">
								    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
								    <ul class="dropdown-menu">
								    	<?php
								    	$result = mysqli_query($db, $sql_statement);
								    	while ($row = mysqli_fetch_assoc($result))
										{
											$dep_city = $row['airport_city'];
											$dep_id   = $row['airport_id'];

											echo "<li class='dropdown-item' id='dep'>" . $dep_city . " (" . $dep_id . ")" . "</li>"; 
										}
								      	?>
								    </ul>
								</div>
							</div>    				
		    			</div>
		    			<div class="form-group col-md-6">
		      				<div class="input-group mb-3">
			  					<input type="text" class="form-control" placeholder="Arrival Airport" aria-label="Arrival Airport" 
			  					aria-describedby="button-addon2" id="arrival" name="arrival_airport">
			  					<div class="input-group-append">
								    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
								    <ul class="dropdown-menu">
								      <?php
								        $result2 = mysqli_query($db, $sql_statement);
								    	while ($row = mysqli_fetch_assoc($result2))
										{
											$arr_city = $row['airport_city'];
											$arr_id   = $row['airport_id'];

											echo "<li class='dropdown-item' id='arr'>" . $arr_city . " (" . $arr_id . ")" . "</li>"; 
										}
								      	?>
								    </ul>
								</div>
							</div>
		    			</div>
				    </div>
				    <div class="form-row justify-content-center"> 
				    	<div class="form-group col-md-6">	
		                	<input type="date" id="f_date" class="form-control" name="flight_date"/>
		                </div>               
				    </div>
				    <div class="form-row justify-content-center">
				    	<button type="button" class="btn btn-outline-light" id ="sub">Search Flights</button>
				    </div>
				</form>
			</div>
		</div>
	</div>
	<script src="js/main.js"></script>
</body>
</html>