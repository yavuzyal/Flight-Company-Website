<?php 

include_once "config.php";

if (isset($_SESSION["candidate_user"]) && isset($_POST["changePassword"]))
{
	$new_password = $_POST["newPassword"];
	$username = $_SESSION["candidate_user"];

	$stmt = "UPDATE users U SET U.user_pass = '$new_password' WHERE U.user_id = '$username'";
	$result = mysqli_query($db, $stmt);
	if ($result)
	{
		unset($_SESSION["candidate_user"]);
		header("Location: login.php?msg=" . urlencode("Your password is successfully changed!"));
	}
	else {
		$error = "An unexpected error has occurred while updating your password. Please try again.";
	}
}
?>