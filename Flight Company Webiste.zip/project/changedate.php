<?php 
if (isset($_POST["newDate"]) && isset($_POST["f_id3"])) {

  $id = $_POST['f_id3'];
  $date = $_POST['newDate'];

  $current_date = date('Y-m-d H:i:s');

  $sql_f_date = "SELECT flight_date FROM flights WHERE flight_id = '$id'";
  $result = mysqli_query($db, $sql_f_date);
  $row = mysqli_fetch_assoc($result);
  $flight_date = $row['flight_date'];

  if ($current_date <= $flight_date and $date >= $current_date)
  {
    $sql_discount = "UPDATE flights SET flight_date = '$date' WHERE flight_id = '$id'";

    if (!mysqli_query($db, $sql_discount))
    {
      $date_error = "An unexpected error has occurred.";
    }
    else {
      $date_result = "The date of the flight is successfully changed.";
    }
  }
  else
  {
    $date_error = "You cannot change date of this flight!";
  }                  
}
?>



