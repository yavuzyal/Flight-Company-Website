<?php 

// Start the session
session_start();

?>


<!DOCTYPE html>
<html>
<html lang="en">
<head>
  <title>FINAL PURCHASE</title>
<meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

  <style type="text/css">
      .navbar-brand {
        font-family: 'Dancing Script', cursive;
        font-size: 35px;
      } 
  </style>
	

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
   		<link rel='stylesheet' href='table_search.css'>
      <link rel='stylesheet' href='plane.css'>

 </head>


<body>
 <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="main.php">IDK Airlines</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="userActions">
      <ul class="navbar-nav ml-auto">
        <?php if (!isset($_SESSION["user"]) && !isset($_SESSION["admin"])): ?>
        <li class="nav-item">
            <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
            <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
            <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
          </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" style="color: #fff" href="login.php">Login
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
          <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
        </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <span class="navbar-text">Welcome 
          <?php if (isset($_SESSION["user"])): ?> 
            <?php echo $_SESSION["user"] ?></span>
          <?php elseif (isset($_SESSION["admin"])): ?>
            <?php echo $_SESSION["admin"] ?></span>
          <?php endif; ?>
            <div class="btn-group">
          <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="far fa-user fa-lg"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <?php if (isset($_SESSION["user"])): ?> 
              <button class="dropdown-item" type="button" id="userProfile">Profile Page</button>
            <?php elseif (isset($_SESSION["admin"])): ?>
              <button class="dropdown-item" type="button" id="adminPanel">Admin Panel</button>
            <?php endif; ?>
            <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
          </div>
        </div> 
        </li> 
        <?php endif ?>
      </ul>
    </div>
  </nav>






<?php

	include_once 'config.php';
	  $user_id;
	  $telno = $_POST['tel_no'];
	  $seatno = $_POST['seat_no'];
	  $fname = $_POST['fname'];
	  $lname = $_POST['lname'];
	  $flight_id = $_POST['id_flight'];
	  $normal_price = $_POST['normal_price'];
	  $vip_price = $_POST['vip_price'];
	  $original_price ;
	  global $sql;

      $sql = "SELECT *
              FROM flights FL
              WHERE FL.flight_id = '$flight_id' ";




	  $result = mysqli_query($db, $sql);
	  $rowcount = mysqli_num_rows($result);
	  $row = mysqli_fetch_array($result);
    $dc_ratio = $row["flight_discratio"];
	  $original_price = number_format(($row['flight_price'] * ((100-$dc_ratio) / 100)) , 2, '.', '');


	if (!$db) {
  		die("Connection failed: " . mysqli_connect_error());
	}
	$param3;
	if (1 <= $seatno && $seatno <= 24){
	  	$param3 = "VIP";
	  }
	  else
	  	$param3 = "NORMAL";
	 		


	  if(! isset($_SESSION['user']) ){

	  		global $sql0;

      		$sql0 = "SELECT * 
              FROM visitor_cnt VC
              ORDER BY VC.counter
              DESC";

      $result0 = mysqli_query($db, $sql0);
	 		$row0 = mysqli_fetch_array($result0);
	  		
	 		$temp = $row0['counter'];
	  		$user_id = "visitor" ;
	  		$temp = $temp + 1 ;
	  		$user_id .= $temp; 
	  		$name  =  $fname;
	  		$name .= " " ;
	  		$name .= $lname ;
	  		$sql1 = "INSERT INTO `visitor_cnt`(`counter`) VALUES (0)"; 
	  		mysqli_query($db, $sql1);
	  		$sql0 = "INSERT INTO users(user_id, user_pass, user_name, user_phone, user_discpoint, user_loyalty, user_status) VALUES ('$user_id','00000','$name','$telno',0,0,0)";
	  		mysqli_query($db, $sql0);
			 

	  }
	  else {
	  	$user_id = $_SESSION['user']; 
	  	global $sql1;

      		$sql1 = "SELECT * 
              FROM users US
              WHERE US.user_id = '$user_id'";
            $sequel;
            $result1 = mysqli_query($db, $sql1);
	 		$row1 = mysqli_fetch_array($result1);
	 		$disc = $row1['user_discpoint'];
	 		if( ($original_price - $normal_price) == 0 && ($param3 == "NORMAL"))
	 		{
	 				$new_disc = $disc + $normal_price/100;
	 				$sequel = "UPDATE users SET user_discpoint='$new_disc'  WHERE user_id = '$user_id' ";

	 		}
	 		elseif( ($original_price - $normal_price) != 0 && ($param3 == "NORMAL"))
	 		{
	 				$new_disc = $normal_price/100;
	 				$sequel = "UPDATE users SET user_discpoint='$new_disc'  WHERE user_id = '$user_id' ";
	 		}
	 		elseif( ($original_price - $normal_price) == 0 && ($param3 == "VIP"))
	 		{
	 				$new_disc = $disc + $vip_price/100;
	 				$sequel = "UPDATE users SET user_discpoint='$new_disc'  WHERE user_id = '$user_id' ";
	 		}
	 		elseif( ($original_price - $normal_price) != 0 && ($param3 == "VIP"))
	 		{
	 				$new_disc = $vip_price/100;
	 				$sequel = "UPDATE users SET user_discpoint='$new_disc'  WHERE user_id = '$user_id' ";
	 		}
	 		mysqli_query($db, $sequel);
	  }

	$param1 =  $seatno;
	$param2;

	if (1 <= $seatno && $seatno <= 24){
	  	$param2 = $vip_price;
	}
	  else
	  	$param2 = $normal_price;

	$param4 = 	$user_id;
	$param5 =   $flight_id;
	$param6 = 	$row['flight_remainingseats'];

	$sql = "INSERT INTO `tickets`(`ticket_seatno`, `ticket_price`, `ticket_status`, `user_id`, `flight_id`) VALUES ('$param1' ,'$param2' ,'$param3' , '$param4', '$param5')";

		mysqli_query($db, $sql);
		

	echo "<h1>\n</h1>";
	echo "<h1>\n</h1>";
	echo "<h1>\n</h1>";
	echo "<h1> YOUR PURCHASE HAS SUCCESSFULLY BEEN COMPLETED! </h1>";
	echo "<h1> YOU WILL BE REDIRECTED TO YOUR BOARDING PASS IN 5 SECONDS! </h1>";



  echo "<form name = 'form1' action = 'ticket.php' method = 'post'>
    <input type='hidden' name = 'seat_no' value='$seatno' />
    <input type='hidden' name = 'fname' value='$fname' />
    <input type='hidden' name = 'lname' value='$lname' />
    <input type='hidden' name = 'flight_id' value='$flight_id' />
    </form>";




?>

   <script type="text/javascript">  var wait=setTimeout("document.form1.submit();",5000); </script>


<div class="grid-wrap">
  <div class="grid grid-anim"></div>
</div>
<div class="airplane-wrap">
  <div class="airplane" id="airplane">
    <div class="front-cover grp" id="front-cover-grp">
      <div class="plate front-cover-inner"></div>
      <div class="plate front-cover-center"></div>
      <div class="trapezoid front-cover-top"></div>
      <div class="trapezoid front-cover-bottom"></div>
      <div class="trapezoid front-cover-left"></div>
      <div class="trapezoid front-cover-right"></div>
      <div class="bordered-thin front-cover-top-left"></div>
      <div class="bordered-thin front-cover-top-right"></div>
      <div class="bordered-thin front-cover-bottom-left"></div>
      <div class="bordered-thin front-cover-bottom-right"></div>
    </div>
    <div class="body grp" id="body-grp">
      <div class="plate left-cover"></div>
      <div class="plate right-cover"></div>
      <div class="plate top-cover-front"></div>
      <div class="plate top-cover-back"></div>
      <div class="cockpit grp" id="cockpit-grp">
        <div class="plate roof"></div>
        <div class="bordered window-fill front-window"></div>
        <div class="window left-window"></div>
        <div class="window right-window"></div>
        <div class="bordered window-fill rear-window"></div>
      </div>
      <div class="plate bottom-cover"></div>
      <div class="plate back-cover"></div>
    </div>
    <div class="top-tail grp" id="top-tail-grp">
      <div class="plate tail-top"></div>
      <div class="plate tail-front"></div>
      <div class="plate tail-back"></div>
      <div class="plate-no-border tail-left-rect"></div>
      <div class="triangle tail-triangle-left-bottom"></div>
      <div class="triangle tail-triangle-left-top"></div>
      <div class="plate-no-border tail-right-rect"></div>
      <div class="triangle tail-triangle-right-bottom"></div>
      <div class="triangle tail-triangle-right-top"></div>
      <div class="bordered tail-connector"></div>
    </div>
    <div class="right-tail grp" id="right-tail-grp">
      <div class="plate tail-top"></div>
      <div class="plate tail-front"></div>
      <div class="plate tail-back"></div>
      <div class="plate-no-border tail-left-rect"></div>
      <div class="triangle tail-triangle-left-bottom"></div>
      <div class="triangle tail-triangle-left-top"></div>
      <div class="plate-no-border tail-right-rect"></div>
      <div class="triangle tail-triangle-right-bottom"></div>
      <div class="triangle tail-triangle-right-top"></div>
      <div class="bordered tail-connector"></div>
    </div>
    <div class="left-tail grp" id="left-tail-grp">
      <div class="plate tail-top"></div>
      <div class="plate tail-front"></div>
      <div class="plate tail-back"></div>
      <div class="plate-no-border tail-left-rect"></div>
      <div class="triangle tail-triangle-left-bottom"></div>
      <div class="triangle tail-triangle-left-top"></div>
      <div class="plate-no-border tail-right-rect"></div>
      <div class="triangle tail-triangle-right-bottom"></div>
      <div class="triangle tail-triangle-right-top"></div>
      <div class="bordered tail-connector"></div>
    </div>
    <div class="wing grp" id="wing-grp">
      <div class="plate wing-right"></div>
      <div class="plate wing-right bottom"></div>
      <div class="plate wing-left"></div>
      <div class="plate wing-left bottom"></div>
      <div class="bordered conector right"></div>
      <div class="bordered conector left"></div>
    </div>
    <div class="propeller rotate-propeller grp" id="propeller-grp">
      <div class="plate propeller-center"></div>
      <div class="plate propeller-center top"></div>
      <div class="plate p-w propeller-wing-1"></div>
      <div class="plate p-w propeller-wing-2"></div>
      <div class="plate p-w propeller-wing-3"></div>
      <div class="plate p-w propeller-wing-4"></div>
      <div class="plate p-w propeller-wing-5"></div>
      <div class="plate p-w propeller-wing-6"></div>
      <div class="plate p-w propeller-wing-7"></div>
      <div class="plate p-w propeller-wing-8"></div>
    </div>
  </div>
</div>





</body>
</html>
