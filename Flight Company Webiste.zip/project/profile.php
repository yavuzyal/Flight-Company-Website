<?php

session_start();

include_once "config.php";
include ("dbPasswordUpdate.php");
include ("deleteAccount.php");
include ("updatePhoneNumber.php");

if (!isset($_SESSION['user']))
{
  echo 
  "<div class='modal' id='myModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
              <h5 class='modal-title text-center'>You are not allowed here.</h5>
              <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
              </button>
            </div>
            <div class='modal-body'>
              <p>You are being redirected to main page.</p>
            </div>
            <div class='modal-footer'>
              <button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
            </div>
        </div>
      </div>
  </div>";
}

else {
  $user = $_SESSION["user"];

  $sql_statement = "SELECT * FROM users WHERE user_id = '$user'";
  $result = mysqli_query($db, $sql_statement);
  $row = mysqli_fetch_assoc($result);

  $user_pass = $row['user_pass'];
  $name_surname = $row['user_name'];
  $phone = $row['user_phone'];
  $discount_points = $row['user_discpoint'];
  $discount_points = number_format($discount_points, 2, '.', '');
  $user_loyalty = $row['user_loyalty'];

}

if (isset($_GET["msg"]))
{
  echo "<div class='alert mb-0 ";

  if ($_GET["msg"] == "Refund request is sent successfully.")
    echo 'alert-success';
  else
    echo 'alert-danger';

  echo "' id='MyPopup' role='alert'>" . urldecode($_GET['msg']) . 
  "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
}

?>


<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>My Profile</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="profile.css" >

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</head>

<body>

  <?php 
  if (isset($update_pass_result))
  {
    echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $update_pass_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }

  if (isset($update_phone_result))
  {
    echo "<div class='alert alert-success mb-0' id='MyPopup' role='alert'>" . $update_phone_result . 
    "<button type='button' id='btnClosePopup' class='close' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
  }
  ?>
  <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-dark bg-primary border-bottom">
        <a class="navbar-brand ml-2" href="main.php">IDK Airlines</a>
        <div class="d-flex flex-row order-2 order-lg-3">
	        <ul class="navbar-nav flex-row">    
	            <li class="nav-item">
	              <span class="navbar-text"> <?php if(isset($_SESSION["user"])) echo $_SESSION["user"]; ?></span>
	                <div class="btn-group">
	                  <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                    <i class="far fa-user fa-lg"></i>
	                  </button>
	                  <div class="dropdown-menu dropdown-menu-right">
	                    <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
	                  </div>
	                </div> 
	            </li>
	        </ul>
        	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          	<span class="navbar-toggler-icon"></span>
        	</button>
       	</div>
         
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            
            <li class="nav-item d-md-none">
            	 <a href="profile.php?view=changepass" class="nav-link">Change Password</a>
            </li>
            <li class="nav-item d-md-none">
            	<a href="profile.php?view=viewhist" class="nav-link">View Purchase History</a>
            </li>
			<li class="nav-item d-md-none">
				<a href="profile.php?view=deleteacc" class="nav-link">Delete Account</a>
            </li>
            <li class="nav-item d-md-none">
				<a href="profile.php?view=changephone" class="nav-link">Change Telephone Number</a>
            </li>
            <li class="nav-item d-md-none">
				<a href="logout.php" class="nav-link">Logout</a>
            </li> 
          </ul>
        </div>
        
      </nav>
    </div>

  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-outline-primary border-right" id="sidebar-wrapper">
      <div class="media mt-4 mb-5 ml-3">
          <span class="media-left">
              <?php if ($user_loyalty == "BRONZE"): ?>
                <img src="bronze.png" class="mt-2" width="65" height="65">
              <?php elseif ($user_loyalty == "GOLDEN"): ?>
                <img src="gold.png" width="65" height="65">
              <?php else: ?>
                <img src="diamond.png" width="65" height="65">
              <?php endif; ?>
          </span>
          <div class="media-body ml-3 mt-n2">
              <p><?php if(isset($_SESSION["user"])) echo "$name_surname" ?></p>
              <p>IDK Points: <?php if(isset($_SESSION["user"])) echo "$discount_points" ?></p>
              <p> <?php echo $user_loyalty . " MEMBER"; ?></p>
          </div>
      </div>
      <div class="list-group list-group-flush">
        <a href="profile.php?view=changepass" class="list-group-item list-group-item-action bg-light">Change Password</a>
        <a href="profile.php?view=viewhist" class="list-group-item list-group-item-action bg-light">View Purchase History</a>
        <a href="profile.php?view=deleteacc" class="list-group-item list-group-item-action bg-light">Delete Account</a>
        <a href="profile.php?view=changephone" class="list-group-item list-group-item-action bg-light">Change Telephone Number</a>
        <a href="logout.php" class="list-group-item list-group-item-action bg-light">Logout</a>

      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <div class="container-fluid">
        <div class="row">   
          <?php if (isset($_GET["view"]) && $_GET["view"] == "changepass"): ?>
            <div class="col-md-9 ml-sm-auto px-md-3 mt-5">
              <h2 class="display-5 ml-5">Change Password</h2>
              <p class="lead">Enter your current and new passwords below.</p>
              <?php echo "<form id='passForm' action='profile.php?view=" . $_GET["view"] . "' method='POST'>" ?>
                <input type="hidden" id="hiddenSend" name="send">
                  <div class="form row">
                    <div class="form-group col-md-6 ml-n4">
                      <label for="inputOldPass" class="col-form-label">Enter your old password</label>
                        <input type="password" class="form-control" name="oldPassword" id="inputOldPass" 
                        required>
                    </div>
                  </div>
                  <div class="form row">
                    <div class="form-group col-md-6 ml-n4">
                      <label for="inputNewPass" class="col-form-label">Enter your new password</label>
                        <input type="password" class="form-control" name="newPassword" id="inputNewPass" required>
                    </div>
                    <div id="passwordValidation" class="text-danger ml-n2 mt-n2" style="display: none;">
                      Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters
                    </div>  
                  </div>
                  <div class="form row">
                    <div class="form-group col-md-6 ml-n4">
                      <label for="inputConfirm" class="col-form-label">Confirm your new password</label>
                        <input type="password" class="form-control" id="inputConfirm" required>
                    </div>
                  </div>
                  <div id="passwordConfirm" class="text-danger ml-1 mt-n1" style="display: none;">
                    Passwords do not match. Try again.
                  </div>
                  <div id="passwordSame" class="text-danger ml-1 mt-n1" style="display: none;">
                    The current and new passwords are same.
                  </div>   
                  <?php if (isset($error)): ?>
                  <div class="text-danger ml-5" id="passwordInvalid"><?php echo $error; ?></div>
                <?php endif; ?> 
                  <div class="form row">
                    <div class="form-group col-md-5 mt-2 justify-content-center" style="margin-left: 150px;">
                      <button type="button" id="buttonSend" class="btn btn-primary mt-2">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            <?php elseif (isset($_GET["view"]) && $_GET["view"] == "viewhist"): ?>
              <div class="col-md-11 ml-sm-auto px-md-3 mt-5">
                <h2 class="display-4" style="margin-left: -2.5rem; font-size: 2.5rem;">Your Flight History</h2>
                <table class="table table-hover mt-5 ml-n5">
                <thead>
                  <tr>
                    <th scope="col">Departure Airport</th>
                    <th scope="col">Arrival Airport</th>
                    <th scope="col" class="pl-5">Date</th>
                    <th scope="col">Seat Number</th>
                    <th scope="col">Price</th>
                    <th scope="col">Status</th>
                    <th scope="col" class="pl-4">Refund</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                    $sql_tickets = "SELECT * FROM tickets WHERE user_id = '$user'";
                  $result = mysqli_query($db, $sql_tickets);

                  while($row = mysqli_fetch_assoc($result))
                  {
                    $seat_no = $row['ticket_seatno'];
                    $org_price = number_format($row['ticket_price'], 2, '.', '');
                    $price = $org_price . " TL";
                    $status = $row['ticket_status'];
                    $flight_id = $row['flight_id'];

                    $sql_flight_info = "SELECT * FROM flights WHERE flight_id = '$flight_id'";
                    $flight_res = mysqli_query($db, $sql_flight_info);

                    $flight_row = mysqli_fetch_assoc($flight_res);

                    $dep_airport = $flight_row['flight_dep_airport'];
                    $arr_airport = $flight_row['flight_arr_airport'];
                    $date = $flight_row['flight_date'];
                    $current_date = date('Y-m-d H:i:s');

                    echo "<tr>" . "<td class='pl-5'>" . $dep_airport . "</td>" . "<td class='pl-5'>" . $arr_airport . "</td>" . "<td>" . $date . "</td>" . "<td class='pl-5'>" . $seat_no . "</td>" . "<td>" . $price . "</td>" . "<td>" . $status . "</td>" . "<td>";

                      if ($status == "NORMAL" || $current_date > $date)
                        echo "<a href='#' class='disabled ml-n2'>Refund Request</a>"  . "</td>"  . "</tr>"; 
                      elseif ($status == "VIP") 
                        echo "<a href='sendrefundrequest.php?f_id=" . urlencode($flight_id) . "&u_id=" . urlencode($_SESSION["user"]) . "&seat=" . urlencode($seat_no) . "' class=' ml-n2'>Refund Request</a>" . "</td>" . "</tr>"; 
                    }
                    
                   ?>
                </tbody>
              </table>
            </div>
          <?php elseif (isset($_GET["view"]) && $_GET["view"] == "deleteacc"): ?>
            <div class="col-md-9 ml-sm-auto mt-5">
              <h1 class="ml-4">Delete Account</h1>
              <p class="lead ml-3">Everything comes to an end one day. </p>
              
              <?php echo "<form id='deleteForm' action='profile.php?view=" . $_GET["view"] . "' method='POST'>" ?>
                <input type="hidden" id="hiddenDelSend" name="delSend">
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="inputDelPassword" class="col-form-label">Enter your password</label>
                        <input type="password" name="passw"  class="form-control" id="inputDelPassword" required>
                    </div>
                  </div>
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="inputDelConfirm" class="col-form-label">Confirm your password</label>
                        <input type="password" class="form-control" id="inputDelConfirm" required>
                    </div>
                  </div>
                  <div id="passwordDelConfirm" class="text-danger mt-n1 ml-5" style="display: none;">
                    Passwords do not match. Try again.
                  </div>    
                  <?php if (isset($del_error)): ?>
                  <div class="text-danger ml-4" id="delError"><?php echo $del_error; ?></div>
                <?php endif; ?> 
                  <div class="form row">
                    <div class="form-group col-md-5 mt-2 justify-content-center" style="margin-left: 150px;">
                      <button type="button" id="buttonDel" class="btn btn-primary mt-2">Submit</button>
                    </div>
                  </div>
                </form>
          <?php elseif (isset($_GET["view"]) && $_GET["view"] == "changephone"): ?>
            <div class="col-md-9 ml-sm-auto px-md-3 mt-5">
              <h2 class="display-5 ml-1">Change Your Phone Number</h2>
              <p class="lead" style="margin-left: -5rem;">
              Give us the following information and we change your phone number easily.</p>
              <?php echo "<form id='phoneForm' class='mt-4 ml-1' action='profile.php?view=" . $_GET["view"] . "' method='POST'>" ?>
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="inputPass" class="col-form-label">Enter your password</label>
                        <input type="password" class="form-control" name="currPassword" id="inputPass" required>
                    </div>
                  </div>
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="inputOldPhone" class="col-form-label">Enter your current phone number</label>
                        <input type="tel" class="form-control" name="oldPhone" id="inputOldPhone" required>
                    </div>
                  </div>
                  <div class="form row">
                    <div class="form-group col-md-5">
                      <label for="inputNewPhone" class="col-form-label">Enter your new phone number</label>
                        <input type="tel" class="form-control" name="newPhone" id="inputNewPhone" required
                        pattern="[+]{1}[0-9]{2,3}[0-9]{10}" title="Must contain the following form: '+(COUNTRY CODE)XXXXXXXXXX' (don't use paranthesis)">
                    </div>
                  </div>
                  <?php if (isset($phone_error)): ?>
                    <div class="text-danger ml-2" id="phoneError"><?php echo $phone_error; ?></div>
                  <?php endif; ?> 
                <div class="form row">
                    <div class="form-group col-md-5 mt-2 justify-content-center" style="margin-left: 150px;">
                      <button type="submit" name="buttonPhone" class="btn btn-primary mt-2">Submit</button>
                    </div>
                  </div>
                </form>
            </div>
            <?php endif; ?> 
        </div>
      </div>
  </div>

  <script src="js/profile.js"></script>
</body>
</html>
