<?php  

session_start();

if (isset($_SESSION['user']) || isset($_SESSION['admin']))
{
	echo 
	"<div class='modal' id='myModal' tabindex='-1' role='dialog'>
  		<div class='modal-dialog' role='document'>
   			<div class='modal-content'>
      			<div class='modal-header'>
        			<h5 class='modal-title text-center'>You are not allowed here.</h5>
        			<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          				<span aria-hidden='true'>&times;</span>
        			</button>
      			</div>
      			<div class='modal-body'>
       				<p>You are being redirected to main page.</p>
      			</div>
      			<div class='modal-footer'>
        			<button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
      			</div>
    		</div>
  		</div>
	</div>";
}

include_once "config.php";
include ("forgotpasswordcheck.php");
?>

<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
	
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <style type="text/css">
    	.navbar-brand {
			font-family: 'Dancing Script', cursive;
  			font-size: 25px;
  			margin-left: 1rem;
		}
		.nav-item {
			margin-right: 20px;
		}
    </style>

	<title>Password Change Page</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <a class="navbar-brand" href="main.php">IDK Airlines</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="userActions">
	    <ul class="navbar-nav ml-auto">
	    	<li class="nav-item">
		        <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
					  <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
					  <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
					</svg></a>
	    	</li>
	    	<li class="nav-item">
		        <a class="nav-link" style="color: #fff" href="login.php">Login
		        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
				  <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
				</svg></a>
	    	</li>
	    </ul>
	  </div>
	</nav>

	<div class="container" style="margin-top: 100px;">
		<h2 class="display-5 mx-3">Let us help you! </h2>
		<p class="lead mx-3">
 		 Give us the answers of the questions below and we will redirect you to change your password!
		</p>
		
		<div class="card" style="border:none">
  			<div class="card-body">
  				<form action="forgotpassword.php" method="POST">
  					<div class="form row">
  						<div class="form-group col-md-6">
    						<label for="inputUsername" class="col-form-label">Your Username</label>
      						<input type="text" class="form-control" name="username" id="inputUsername" required>
  						</div>
  						<div class="form-group col-md-6">
	    					<label for="inputPhone" class="col-form-label">Your Telephone Number</label>
	      					<input type="tel" class="form-control" name="phoneno" id="inputPhone" pattern="[+]{1}[0-9]{2,3}[0-9]{10}" required title="Must contain the following form: '+(COUNTRY CODE)XXXXXXXXXX' (don't use paranthesis)">
	    				</div>
  					</div>
  					<div class="form row">
  						<div class="form-group col-md-6">
  							<label for="inputQuestion" class="col-form-label">What was your security question?</label>
		  					<div class="input-group">
								<select class="form-control" id="inputQuestion" name="question">
						     		<option>What was your childhood nickname?</option>
						    		<option>What is the name of your favorite childhood friend?</option>
						    		<option>What street did you live on in third grade?</option>
						    		<option>What is your oldest sibling's middle name?</option>
						    		<option>What school did you attend for sixth grade?</option>
						    		<option>What was the last name of your third grade teacher?</option>
						    		<option>In what city or town was your first job?</option>
						    		<option>Where were you when you first heard about 9/11?</option>
						    		<option>What is the name of the company of your first job?</option>
						    		<option>What is your oldest cousin's first and last name?</option>
						   		</select>
							</div>
						</div>
						<div class="form-group col-md-6">
		    				<label for="inputAnswer" class="col-form-label">Your Answer</label>
		      				<input type="text" class="form-control" name="answer" id="inputAnswer" required>
    					</div>
  					</div>
  					<?php if (isset($error)): ?>
						<div class="text-danger text-center"><?php echo $error; ?></div>
					<?php endif ?>  
  					<div class="form row justify-content-center mt-3">
  						<button type="submit" name="continue" class="btn btn-primary">Continue</button>
  					</div>
  				</form>
  			</div>
		</div>
	</div>

	<script type="text/javascript">
		$(document).ready(function() {
            $('#myModal').modal('show');
        });

		$("#redirectButton").click(function() {
			window.location.href = "main.php";
		});
	</script>
</body>
</html>