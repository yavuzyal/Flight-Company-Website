<?php 

session_start();

include_once "config.php";

if (isset($_GET["f_id"]) && isset($_GET["u_id"]) && isset($_GET["seat"]) && isset($_SESSION["user"]))
{
	$flight_id = $_GET["f_id"];
	$user_id = $_GET["u_id"];
	$seat_no = $_GET["seat"];

	// for status check
	$ticket_check = "SELECT * FROM tickets WHERE tickets.ticket_seatno = '$seat_no' AND tickets.user_id = '$user_id' AND tickets.flight_id = '$flight_id'";
	$check_result = mysqli_query($db, $ticket_check);
	$row = mysqli_fetch_assoc($check_result);
	$status = $row["ticket_status"];

	if ($status == "VIP")
	{
		$insert_check = "SELECT * FROM refunds WHERE refunds.user_id = '$user_id' AND refunds.flight_id = '$flight_id' AND refunds.seat_no = '$seat_no'";
		$insert_check_res = mysqli_query($db, $insert_check);

		if (mysqli_num_rows($insert_check_res) <= 0)
		{
			$insert_stmt = "INSERT INTO refunds VALUES ('$user_id', '$flight_id', '$seat_no')";
			$insert_result = mysqli_query($db, $insert_stmt);
			if ($insert_result)
			{
				header("Location: profile.php?view=viewhist&msg=" . urlencode("Refund request is sent successfully."));
			}
			else {
				header("Location: profile.php?view=viewhist&msg=" . urlencode("An error has occurred while sending a refund request."));
			}
		}
		else {
			header("Location: profile.php?view=viewhist&msg=" . urlencode("You have already sent a refund request for this ticket."));
		}
	}
	else {
		header("Location: profile.php?view=viewhist&msg=" . urlencode("You are not allowed to request a refund."));
	}
}
?>

