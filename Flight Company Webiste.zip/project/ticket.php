<?php 

// Start the session
session_start();

?>


<!DOCTYPE html>
<html>
<html lang="en">
<head>
<meta charset="utf-8">
   <link rel='stylesheet' href='ticket.css'>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.gstatic.com/%22%3E"> 
  <link href="https://fonts.googleapis.com/css2?family=Titan+One&display=swap" rel="stylesheet">

  <style type="text/css">
      .navbar-brand {
        font-family: 'Dancing Script', cursive;
        font-size: 35px;
      }   
  </style>

  

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
      <link rel='stylesheet' href='table_search.css'>
      <link rel='stylesheet' href='banner.css'>


      <link rel="preconnect" href="https://fonts.gstatic.com/%22%3E"> 
      <link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">

 </head>
<body>



<body>
 <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="main.php">IDK Airlines</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="userActions">
      <ul class="navbar-nav ml-auto">
        <?php if (!isset($_SESSION["user"]) && !isset($_SESSION["admin"])): ?>
        <li class="nav-item">
            <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
            <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
            <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
          </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" style="color: #fff" href="login.php">Login
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
          <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
        </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <span class="navbar-text">Welcome 
          <?php if (isset($_SESSION["user"])): ?> 
            <?php echo $_SESSION["user"] ?></span>
          <?php elseif (isset($_SESSION["admin"])): ?>
            <?php echo $_SESSION["admin"] ?></span>
          <?php endif; ?>
            <div class="btn-group">
          <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="far fa-user fa-lg"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <?php if (isset($_SESSION["user"])): ?> 
              <button class="dropdown-item" type="button" id="userProfile">Profile Page</button>
            <?php elseif (isset($_SESSION["admin"])): ?>
              <button class="dropdown-item" type="button" id="adminPanel">Admin Panel</button>
            <?php endif; ?>
            <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
          </div>
        </div> 
        </li> 
        <?php endif ?>
      </ul>
    </div>
  </nav>



<?php

    $seatno = $_POST['seat_no'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $flight_id = $_POST['flight_id'];

    $name = $fname;
    $name .= ' ';
    $name .= $lname;




   include_once 'config.php';

  global $sql;

      $sql = "SELECT *
              FROM flights FL, airports AP
              WHERE FL.flight_id = '$flight_id'";


    $result = mysqli_query($db, $sql);

    $row = mysqli_fetch_array($result);

    if (!$db) {
      die("Connection failed: " . mysqli_connect_error());
    }

    $date =   $row['flight_date'];
    $arrival =   $row['flight_arr_airport'];
    $departure =   $row['flight_dep_airport'];


    $sql1 = "SELECT *
              FROM airports AP
              WHERE AP.airport_id = '$arrival'";


    $result = mysqli_query($db, $sql1);
    $row = mysqli_fetch_array($result);


    $rent_car =   $row['airport_rent'];
    $hotel =   $row['airport_hotel'];

    $tempdate = "2020";
    $tempdate2 = "2021";
    if( isset($_SESSION['user']) ) {
    $usersid = $_SESSION['user'];
    $new_sql = "SELECT COUNT(*) AS count, AVG(TS.ticket_price) AS average
    FROM users US, tickets TS, flights FS
    WHERE US.user_id = '$usersid' AND TS.user_id = '$usersid' AND TS.flight_id = FS.flight_id AND (FS.flight_date LIKE '%{$tempdate}%' OR FS.flight_date LIKE '%{$tempdate2}%') 
    GROUP BY US.user_id";
    $my_result = mysqli_query($db, $new_sql);
    $my_row = mysqli_fetch_array($my_result);       
    $count = $my_row['count'];
    $avg = $my_row['average'];
    $last_sql;
   
    if ( $count > 5 && $avg >200){
      $last_sql = "UPDATE users SET user_loyalty= 'DIAMOND' WHERE user_id = '$usersid' ";
      

    }
    elseif ( $count > 5 && $avg >100){
      $last_sql = "UPDATE users SET user_loyalty= 'GOLDEN' WHERE user_id = '$usersid'";
      

    }
    else{
      $last_sql = "UPDATE users SET user_loyalty= 'BRONZE' WHERE user_id = '$usersid'";
      

    }

    mysqli_query($db, $last_sql);
    
    }

?>



<div class="box">
  <ul class="left">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
  
  <ul class="right">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
  <div class="ticket">
    <span class="airline">IDK AIRLINES</span>
    <span class="airline airlineslip">IDK AIRLINES</span>
    <span class="boarding">Boarding pass</span>
    <div class="content">
      <span class="jfk"><?php echo $departure; ?></span>
      <span class="plane"><?xml version="1.0" ?><svg clip-rule="evenodd" fill-rule="evenodd" height="60" width="60" image-rendering="optimizeQuality" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg"><g stroke="#222"><line fill="none" stroke-linecap="round" stroke-width="30" x1="300" x2="55" y1="390" y2="390"/><path d="M98 325c-9 10 10 16 25 6l311-156c24-17 35-25 42-50 2-15-46-11-78-7-15 1-34 10-42 16l-56 35 1-1-169-31c-14-3-24-5-37-1-10 5-18 10-27 18l122 72c4 3 5 7 1 9l-44 27-75-15c-10-2-18-4-28 0-8 4-14 9-20 15l74 63z" fill="#222" stroke-linejoin="round" stroke-width="10"/></g></svg></span>
      <span class="sfo"><?php echo $arrival; ?></span>
      
      <span class="jfk jfkslip"><?php echo $departure; ?></span>
      <span class="plane planeslip"><?xml version="1.0" ?><svg clip-rule="evenodd" fill-rule="evenodd" height="50" width="50" image-rendering="optimizeQuality" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg"><g stroke="#222"><line fill="none" stroke-linecap="round" stroke-width="30" x1="300" x2="55" y1="390" y2="390"/><path d="M98 325c-9 10 10 16 25 6l311-156c24-17 35-25 42-50 2-15-46-11-78-7-15 1-34 10-42 16l-56 35 1-1-169-31c-14-3-24-5-37-1-10 5-18 10-27 18l122 72c4 3 5 7 1 9l-44 27-75-15c-10-2-18-4-28 0-8 4-14 9-20 15l74 63z" fill="#222" stroke-linejoin="round" stroke-width="10"/></g></svg></span>
      <span class="sfo sfoslip"><?php echo $arrival; ?></span>
      <div class="sub-content">
        <span class="watermark">IDK</span>
        <span class="name">PASSENGER NAME<br><span><?php echo $name; ?></span></span>
        <span class="flight">FLIGHT NUMBER<br><span>  <?php echo $flight_id; ?> </span></span>
        <span class="seat">SEAT<br><span><?php echo $seatno; ?></span></span>
        <span class="boardingtime">BOARDING TIME<br><span><?php echo $date; ?></span></span>
            
         <span class="flight flightslip">FLIGHT NUMBER<br><span><?php echo $flight_id; ?></span></span>
          <span class="seat seatslip">SEAT<br><span><?php echo $seatno; ?></span></span>
         <span class="name nameslip">PASSENGER NAME<br><span><?php echo $name; ?></span></span>
      </div>
    </div>
    <div class="barcode"></div>
    <div class="barcode slip"></div>
  </div>
</div>




        <div id="banner" style="float: right; margin-right:50px margin-top:50px">
            <a >
                <div id="target"></div>
                <img id="product" src="https://images.vexels.com/media/users/3/157231/isolated/preview/7c9a3c3d7e81dc61dfd56a1be6cabc09-simple-house-icon-by-vexels.png">
                <div id="badge">CHECK OUT!</div>
                <div id="sale">
                    <span id="sale-text"><?php echo $hotel; ?></span><br/>
                    <span id="button">Reserve Your Place Now</span>
                </div>
            </a>
        </div>
     


        <div id="banner2">
            <a >
                <div id="target2"></div>
                <img id="product2" src="car.png">
                <div id="badge2">CHECK OUT!</div>
                <div id="sale2">
                    <span id="sale-text2"><?php echo $rent_car; ?></span><br/>
                    <span id="button2">Rent Your Car Now</span>
                </div>
            </a>
        </div>
   



<script src="js/main.js"></script>

</body>
</html>

