<?php 

include_once "config.php";

if (isset($_POST['login']))
{
	$username = $_POST['username'];
	$password = $_POST['pass'];

	$user_stmt  = "SELECT * FROM users WHERE users.user_id = '$username' AND users.user_pass = '$password' AND users.user_status = 1";
	$user_result = mysqli_query($db, $user_stmt);

	if (mysqli_num_rows($user_result) <= 0) {
		$admin_stmt  = "SELECT * FROM admins WHERE admins.admin_id = '$username' AND admins.admin_pass = '$password'";
		$admin_result = mysqli_query($db, $admin_stmt);

		if (mysqli_num_rows($admin_result) <= 0)
		{
			$error = "Your username or password is incorrect.";
		}
		else {
			header("Location: main.php");
  			$_SESSION["admin"] = $username;
		}	
	}
  	else {
  		header("Location: main.php");
  		$_SESSION["user"] = $username;
  	}
}
?>