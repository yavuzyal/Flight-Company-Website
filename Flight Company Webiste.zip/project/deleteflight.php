<?php 

include_once "config.php";

if (isset($_POST["f_id2"]))
{
  $id = $_POST['f_id2'];

  $sql_delete_tickets = "DELETE FROM tickets WHERE flight_id = '$id'";
  //$sql_update_seats = "DELETE FROM tickets WHERE flight_id = '$id'";
  $sql_delete_flight = "DELETE FROM flights WHERE flight_id = '$id'";

  $result = mysqli_query($db, $sql_delete_tickets);
  $result1 = mysqli_query($db, $sql_delete_flight);

  if ($result and $result1)
  {
    $delete_result = "Flight is deleted successfully.";
  }
  else {
    $delete_result = "An unexpected error has occurred while deleting flight.";
  }
}

?>