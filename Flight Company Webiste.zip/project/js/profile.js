$("#logout").click(function() {
	    	window.location.href = "logout.php";
		});

$("#btnClosePopup").click(function () {
	$("#MyPopup").alert('close');
});

$("#buttonSend").click(function () {
	var upperCase= new RegExp('[A-Z]');
	var lowerCase= new RegExp('[a-z]');
	var numbers = new RegExp('[0-9]');

	if ($("#inputNewPass").val() != $("#inputConfirm").val())
	{	
		$("#passwordInvalid").hide();
		$("#passwordSame").hide();
		$("#passwordValidation").hide();	
		$("#inputNewPass").addClass("is-invalid");
		$("#inputConfirm").addClass("is-invalid");
		$("#passwordConfirm").show();
	}

	else if (!($("#inputNewPass").val().match(upperCase) 
			&& $("#inputNewPass").val().match(lowerCase) 
			&& $("#inputNewPass").val().match(numbers) && $("#inputNewPass").val().length >= 8))
	{
		$("#passwordSame").hide();
		$("#passwordConfirm").hide();
        $("#passwordInvalid").hide();
		$("#inputNewPass").addClass("is-invalid");
        $("#inputConfirm").removeClass("is-invalid");
		$("#passwordValidation").show();		
	}

	else if ($("#inputOldPass").val() == $("#inputNewPass").val())
	{
		$("#passwordValidation").hide();
		$("#passwordConfirm").hide();
        $("#passwordInvalid").hide();
        $("#passwordSame").show();
	}

	else {
		$("#hiddenSend").val("1");
		$("#passForm").submit();
	}
});

$(document).ready(function() {
    $('#myModal').modal('show');
});


$("#redirectButton").click(function() {
	window.location.href = "main.php";
});

$("#buttonDel").click(function () {
    if ($("#inputDelPassword").val() != $("#inputDelConfirm").val())
    {      
        $("#delError").hide();
        $("#inputDelPassword").addClass("is-invalid");
        $("#inputDelConfirm").addClass("is-invalid");
        $("#passwordDelConfirm").show();
    }
    else {
        $("#hiddenDelSend").val("1");
        $("#deleteForm").submit();
    }
});