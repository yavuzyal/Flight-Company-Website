$( "#dep.dropdown-item" ).click(function() {
    var value = $(this).text();
    $("#departure").val(value);
});

$( "#arr.dropdown-item" ).click(function() {
    var value = $(this).text();
    $("#arrival").val(value);
});

// parse airport id's
$("#sub").click(function() {
    var arr_airport = $("#arrival").val();
    var dep_airport = $("#departure").val();
    var date = $("input[name='flight_date']").val();

    if (arr_airport.length === 0 || dep_airport.length === 0 || date.length === 0)
        alert("You cannot leave airports/date section empty!");

    else if (arr_airport === dep_airport)
        alert("You cannot select same airports!");
    
    else {
        // just sending the id's of the airports
        var first_index_arr = arr_airport.indexOf("(");
        var last_index_arr = arr_airport.indexOf(")");
        var arr_submitted = arr_airport.substring(first_index_arr + 1, last_index_arr);
    
        var first_index_dep = dep_airport.indexOf("(");
        var last_index_dep = dep_airport.indexOf(")");
        var dep_submitted = dep_airport.substring(first_index_dep + 1, last_index_dep);
    
        $("#departure").val(dep_submitted);
        $("#arrival").val(arr_submitted);
        $( "#search" ).submit();
        $("#departure").val(dep_airport);
        $("#arrival").val(arr_airport);
    }    
});

$("#logout").click(function() {
    window.location.href = "logout.php";
});

$("#btnClosePopup").click(function () {
    $("#MyPopup").alert('close');
});

$("#userProfile").click(function() {
    window.location.href = "profile.php";
});

$("#adminPanel").click(function() {
    window.location.href = "admin_panel.php";
});

// date restriction
$(document).ready(function() {
    var currentDate = new Date();
    
    var month =  currentDate.getMonth() + 1;
    var day =  currentDate.getDate();
    var year =  currentDate.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate = year + '-' + month + '-' + day;
    $('#f_date').attr('min', minDate);
});