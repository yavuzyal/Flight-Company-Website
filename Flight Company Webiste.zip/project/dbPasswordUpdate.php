<?php
include "config.php";

if (isset($_SESSION["user"]) && isset($_POST['send']))
{
	$id = $_SESSION["user"];
	$old_password = $_POST['oldPassword'];
	$new_pass = $_POST['newPassword'];
	$sql_check = "SELECT * FROM users U WHERE U.user_id = '$id' AND U.user_pass = '$old_password'";
	$result = mysqli_query($db, $sql_check);

	if (mysqli_num_rows($result) <= 0)
		$error = "Your password is invalid. Please try again!";
	
	else
	{
		$sql_update = "UPDATE users U SET U.user_pass = '$new_pass' WHERE U.user_id = '$id'";
		if (mysqli_query($db, $sql_update))
		{
	  		$update_pass_result = "Your password is changed successfully.";
		}
		else
		{
	  		$error = "Error: An unexpected problem occurred while changing password.";
		}
	}
}
?>