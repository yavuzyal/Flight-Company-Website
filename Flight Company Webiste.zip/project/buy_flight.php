<?php 

// Start the session
session_start();

?>


<!DOCTYPE html>
<html>
<html lang="en">
<head>
  <title>Search Flights</title>
<meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  <style type="text/css">
  	.navbar-brand {
		font-family: 'Dancing Script', cursive;
		font-size: 35px;
	}
  </style>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
  <link rel='stylesheet' href='buy_flight.css'>
  <link rel='stylesheet' href='container2.css'>
  <link rel='stylesheet' href='radiobutton.css'> 
  <link rel='stylesheet' href='input2.css'>  
  <link rel="preconnect" href="https://fonts.gstatic.com/%22%3E">
  <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">
 </head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="main.php">IDK Airlines</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="userActions">
      <ul class="navbar-nav ml-auto">
        <?php if (!isset($_SESSION["user"]) && !isset($_SESSION["admin"])): ?>
        <li class="nav-item">
            <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
            <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
            <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
          </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" style="color: #fff" href="login.php">Login
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
          <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
        </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <span class="navbar-text">Welcome 
          <?php if (isset($_SESSION["user"])): ?> 
            <?php echo $_SESSION["user"] ?></span>
          <?php elseif (isset($_SESSION["admin"])): ?>
            <?php echo $_SESSION["admin"] ?></span>
          <?php endif; ?>
            <div class="btn-group">
          <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="far fa-user fa-lg"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <?php if (isset($_SESSION["user"])): ?> 
              <button class="dropdown-item" type="button" id="userProfile">Profile Page</button>
            <?php elseif (isset($_SESSION["admin"])): ?>
              <button class="dropdown-item" type="button" id="adminPanel">Admin Panel</button>
            <?php endif; ?>
            <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
          </div>
        </div> 
        </li> 
        <?php endif ?>
      </ul>
    </div>
  </nav>

<?php
  
  include_once 'config.php';

  $user_id;
  $flight_id = $_POST['id_flight'];
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $telno = $_POST['tel_no'];
  $discount;

  if ( isset($_SESSION['user']) ){

    $user_id = $_SESSION['user'];

   if (! isset($_POST['d_points']) )
    {
    
      $discount = 0;
    }

    else 
    {
      $sql0;

      $sql0 = "SELECT *
              FROM users US
              WHERE US.user_id = '$user_id' ";

      $result0 = mysqli_query($db, $sql0);
      $row0 = mysqli_fetch_array($result0);
      $discount = $row0['user_discpoint'];

    }
  }

  else {
     $discount = 0;
  }

  

  global $sql;

  $sql = "SELECT *
          FROM flights FL
          WHERE FL.flight_id = '$flight_id'";



  $result = mysqli_query($db, $sql);
  $rowcount = mysqli_num_rows($result);

  $row = mysqli_fetch_array($result);


  $price = $row['flight_price'];

  $disc = $row['flight_discratio'];

  $price =  $price * ( (100-$disc) / 100 );


      $sql = "SELECT *
              FROM flights FL, tickets T
              WHERE FL.flight_id = '$flight_id' AND T.flight_id = '$flight_id'";



  $result = mysqli_query($db, $sql);
  $rowcount = mysqli_num_rows($result);



  $temp0 = $price - $discount ; 
  $temp0 = number_format($temp0, 2, '.', '');
  if($discount > $price )
  {
    $temp0 = 0;
  }
  $normal_ticket = 'Price for Blue Seats: ';
  $normal_ticket .= $temp0;
  $normal_ticket .= '₺';


  $price = $price * 1.5;
  $temp1 = $price - $discount;
  $temp1 = number_format($temp1, 2, '.', '');
  if($discount > $price )
  {
    $temp1 = 0;
  }
  $vip_ticket = 'Price for Red Seats: ';
  $vip_ticket .= $temp1;
  $vip_ticket .= '₺';

 echo "<form style='float: left; margin-right:50px margin-top:50px'/>
    <div class='segment'>
    <h5>Check Your Information</h5>
    </div>
    <label >
      <input type='text' name = 'fname' value='$fname' disabled/>
    </label>
    <label>
      <input type='text' name = 'lname' value='$lname' disabled/>
    </label>
    <label>
      <input type='text' name = 'tel_no' value='$telno' disabled/>
    </label>

     <div class='segment'>
    <h5 >Prices</h5>
    </div>

    <label>
      <input type='text' value= '$normal_ticket' disabled/>
    </label>

    <label>
      <input type='text'  value='$vip_ticket' disabled/>
    </label>

  </form>";


echo "<form action = 'final_purchase.php' method='post'>";


    echo "<button class = 'red' type = 'submit' style='float: right;'> 
  <i class='icon ion-md-lock'></i>FINISH PURCHASING</button>";
  


 echo "<table class='container'>
  <tbody>
    <tr>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
    </tr>";

   $count = 1;
   
   $temp_init = 1;
   $temp_fin = 6;

   $array_ticket;


   $check;
 

   while ($count <= 174) {

    $result = mysqli_query($db, $sql);

    $temp_result = $result;

    $check = 0;

    while ($array_ticket = mysqli_fetch_array($temp_result)) {

      if ($count == $array_ticket['ticket_seatno'])
        $check = 1;
    }


     
     if ($count == $temp_init){
      echo "<tr>";
      $temp_init = $temp_init + 6;
     }


    if ($count <= 24) {

      if ($check == 0) {
      
       echo" <td>  <label> 
             <input type='radio' name='seat_no' value = '$count' required/>
            <h6>$count</h6> 
            </label> </td>";
              
      }

   
      else{
        echo "<td>  <label> 
             <input class='disabled2' type='radio' name='options' value = '$count'/>
            <h6>$count</h6> 
            </label> </td>";
      }

        }

    else {


      if ($check == 0) {
      
       echo" <td>  <label> 
             <input type='radio' name='seat_no' value = '$count'/>
            <span>$count</span> 
            </label> </td>";
              
      }

   
      else{
        echo "<td>  <label> 
             <input class='disabled2' type='radio' name='options' value = '$count'/>
            <span>$count</span> 
            </label> </td>";
      }

    }

      if ($count == $temp_fin){
      echo "</tr>";
      $temp_fin = $temp_fin + 6;
     }

      $count = $count + 1;

      $count2 = 0;
   }
  echo "  <input name = 'id_flight' type = 'hidden' value = '$flight_id' />";
  echo "  <input name = 'fname' type = 'hidden' value = '$fname' />";
  echo "  <input name = 'lname' type = 'hidden' value = '$lname' />";
  echo "  <input name = 'normal_price' type = 'hidden' value = '$temp0' />";
  echo "  <input name = 'vip_price' type = 'hidden' value = '$temp1' />";
  echo "  <input type='hidden' name = 'tel_no' value='$telno'/>";
  echo "</tbody>
        </table>";



  echo "</form>";


 

?> 



  



<script type="text/javascript">
  


function pay_func( id ){

  $("#myid").val(id);


  document.write ($id);
}

</script>

<script src="js/main.js"></script>

</body>
</html>

  
