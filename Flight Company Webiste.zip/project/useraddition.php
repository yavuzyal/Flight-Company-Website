<?php  

include_once "config.php";

$username = "";
$phoneno = "";

if (isset($_POST['register']))
{
	$name = $_POST['name'];
	$surname = $_POST['surname'];
	$username = $_POST['username'];
	$phoneno = $_POST['phoneno'];
	$password = $_POST['pass'];
	$question = $_POST['question'];
	$answer = $_POST['answer'];
	$finalname = $name . " " . $surname;

	$user_stmt  = "SELECT * FROM users WHERE users.user_id = '$username'";
	$phone_stmt = "SELECT * FROM users WHERE users.user_phone = '$phoneno' AND users.user_status = 1";
	$admin_stmt  = "SELECT * FROM admins WHERE admins.admin_id = '$username'";

	$user_result = mysqli_query($db, $user_stmt);
	$phone_result = mysqli_query($db, $phone_stmt);
	$admin_result = mysqli_query($db, $admin_stmt);

	if (mysqli_num_rows($user_result) > 0 || mysqli_num_rows($admin_result) > 0) {
  		$name_error = "Username is already taken. Please try again with different username.";
  	}

  	else if (mysqli_num_rows($phone_result) > 0)
  		$phone_error = "Telephone number you provided is already in use. Please try again with different number.";

  	else {
  		$insert_query = "INSERT INTO users VALUES ('$username', '$password', '$finalname', '$phoneno', 0, 'BRONZE', 1, '$question', '$answer')";
  		$insert_result = mysqli_query($db, $insert_query);

  		if ($insert_result)
  			header('Location: login.php?msg=' . urlencode("Your account is successfully created!"));

  		exit();
  	}
}
?>