<?php 

// database name: airline_reservation
// servername can be changed wrt port number

$servername = "localhost";
$db = mysqli_connect($servername, 'root', '', 'airline_reservation');

if ($db->connect_errno > 0) {
	die ('Unable to connect to database [' . $db->connect_error . ']');
}

?>