<?php

include_once "config.php";

if (isset($_SESSION["user"]) && isset($_POST['buttonPhone']))
{
	$id = $_SESSION["user"];
	$password = $_POST['currPassword'];
	$old_phone = $_POST['oldPhone'];
	$new_phone = $_POST['newPhone'];

	$sql_check = "SELECT * FROM users U WHERE U.user_id = '$id' AND U.user_pass = '$password' AND U.user_phone = '$old_phone'";
	$check_result = mysqli_query($db, $sql_check);

	$sql_phone_check = "SELECT * FROM users U WHERE U.user_phone = '$new_phone' AND U.user_status = 1";
	$check_phone = mysqli_query($db, $sql_phone_check);

	if (mysqli_num_rows($check_result) <= 0)
	{
		$phone_error = "Your password or phone number is invalid.";
	}

	else if ($old_phone == $new_phone)
	{
		$phone_error = "The new phone number is the same as the current phone number.";
	}

	else if (mysqli_num_rows($check_phone) > 0)
	{
		$phone_error = "The phone number you want to take is already in use.";
	}

	else {
		$sql_update = "UPDATE users U SET U.user_phone = '$new_phone' WHERE U.user_id = '$id' AND U.user_pass = '$password'";

		if (mysqli_query($db, $sql_update))
		{
			$update_phone_result = "Your phone number is successfully updated!";
		}

		else
		{
			$phone_error = "An unexpected error has occurred while updating your phone number.";
		}	
	}
}
?>