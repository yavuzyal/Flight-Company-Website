<?php

include_once "config.php";

if (isset($_SESSION["user"]) && isset($_POST['delSend']))
{
	$id = $_SESSION["user"];
	$password = $_POST['passw'];

	$sql_check = "SELECT * FROM users U WHERE U.user_id = '$id' AND U.user_pass = '$password'";
	$check_result = mysqli_query($db, $sql_check);

	if (mysqli_num_rows($check_result) <= 0)
	{
		$del_error = "Your password is invalid. Maybe this is a sign.";
	}
	else {
		$sql_delete = "UPDATE users U SET U.user_status = 0 WHERE U.user_id = '$id' AND U.user_pass = '$password'";

		if (mysqli_query($db, $sql_delete))
		{
			unset($_SESSION["user"]);
			header('Location: main.php?msg=' . urlencode("Your account has been deleted successfully. Good bye..."));
		}
		else
		{
			$del_error = "An unexpected error has occurred while deleting your account. Maybe this is a sign.";
		}	
	}
}
?>
