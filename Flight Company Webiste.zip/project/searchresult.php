<?php

  session_start();

?>

<!DOCTYPE html>
<html>

<html lang="en">
<head>

  <title>Flight Results</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel='stylesheet' href='table_search.css'>

    <style type="text/css">
      .navbar-brand {
        font-family: 'Dancing Script', cursive;
        font-size: 35px;
      }
      
    </style>

 </head>
<body>

<script>
function sortTable(param) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("mytable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[param];
      y = rows[i + 1].getElementsByTagName("TD")[param];
      //check if the two rows should switch place:
      if (Number(x.innerHTML) > Number(y.innerHTML)) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>




<script>
function sortTablee(param) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("mytable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[param];
      y = rows[i + 1].getElementsByTagName("TD")[param];
      //check if the two rows should switch place:
      if (Number(x.innerHTML) < Number(y.innerHTML)) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>


<script>
function sortTable2(param) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("mytable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[param];
      y = rows[i + 1].getElementsByTagName("TD")[param];
      //check if the two rows should switch place:
      if ((x.innerHTML) > (y.innerHTML)) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>

<script>
function sortTablee2(param) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("mytable");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[param];
      y = rows[i + 1].getElementsByTagName("TD")[param];
      //check if the two rows should switch place:
      if ((x.innerHTML) < (y.innerHTML)) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
</script>
  <nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="main.php">IDK Airlines</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="userActions">
      <ul class="navbar-nav ml-auto">
        <?php if (!isset($_SESSION["user"]) && !isset($_SESSION["admin"])): ?>
        <li class="nav-item">
            <a class="nav-link" id="signup" style="color: #fff" href="signup.php">Sign Up
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
            <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
            <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
          </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" style="color: #fff" href="login.php">Login
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
          <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
        </svg>
            <span class="sr-only">(current)</span></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <span class="navbar-text">Welcome 
          <?php if (isset($_SESSION["user"])): ?> 
            <?php echo $_SESSION["user"] ?></span>
          <?php elseif (isset($_SESSION["admin"])): ?>
            <?php echo $_SESSION["admin"] ?></span>
          <?php endif; ?>
            <div class="btn-group">
          <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="far fa-user fa-lg"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <?php if (isset($_SESSION["user"])): ?> 
              <button class="dropdown-item" type="button" id="userProfile">Profile Page</button>
            <?php elseif (isset($_SESSION["admin"])): ?>
              <button class="dropdown-item" type="button" id="adminPanel">Admin Panel</button>
            <?php endif; ?>
            <button class="dropdown-item" type="button" id="logout" href="logout.php">Logout</button>
          </div>
        </div> 
        </li> 
        <?php endif ?>
      </ul>
    </div>
  </nav>

 



<?php


  include_once 'config.php';


  
  $departure = $_POST['departure_airport'];
  $arrival = $_POST['arrival_airport'];
  $date = $_POST['flight_date'];
 
  global $sql;

      $sql = "SELECT *
              FROM flights FL, aircrafts AC
              WHERE FL.flight_aircraft = AC.aircraft_id  AND FL.flight_arr_airport = '$arrival' AND FL.flight_dep_airport = '$departure' AND FL.flight_date LIKE '%{$date}%'
              ORDER BY FL.flight_popularity 
              DESC";



  $result = mysqli_query($db, $sql);
  $rowcount = mysqli_num_rows($result);


  if($rowcount == 0){
    echo "<h2>THERE IS NO AVAILABLE FLIGHT FOR YOUR PREFERENCES</h2>";}

  else {


    echo "<h1><span class='blue'></span>FLIGHT RESULTS<span class='blue'></span> <span class='yellow'></span></h1>";


    echo "<table class='container' onclick='sorttable()' id = 'mytable'>
            <thead>
              <tr>
                <th><h1>DEPARTURE</h1></th>
                <th ><h1>ARRIVAL</h1></th>
                <th>
                  <h1 onclick='sortTablee2(2)'>DATE ↑</h1> 
                  <h1 onclick='sortTable2(2)'>DATE ↓</h1>
                  </th>
                <th >
                  <h1 onclick='sortTablee(3)'>PRICE ↑</h1> </h1>
                  <h1 onclick='sortTable(3)'>PRICE ↓</h1> </h1>
                  </th>
                <th >
                  <h1 onclick='sortTablee(4)'>REMAINING SEATS ↑</h1>
                  <h1 onclick='sortTable(4)'>REMAINING SEATS ↓</h1>
                  </th>
                <th><h1>AIRCRAFT NAME</h1></th>
                <th><h1></h1></th>
                <th><h1></h1></th>
              </tr>
            </thead>";

            while($row = mysqli_fetch_array($result)) {

           
              $disc = $row['flight_discratio'];
              $price = $row['flight_price'];

              $new_price =  $price * ( (100-$disc) / 100 );
              $new_price = number_format($new_price, 2, '.', '');

              echo "<tbody><tr>";
              echo "<td>" . $row['flight_dep_airport'] . "</td>";
              echo "<td>" . $row['flight_arr_airport'] .  "</td>";
             # echo "<td>" . $selectdate . "</td>";
              echo "<td>" . $row['flight_date'] . "</td>";
              echo "<td>" . $new_price . "</td>";
              echo "<td>" . $row['flight_remainingseats'] . "</td>";
              echo "<td>" . $row['aircraft_name'] . "</td>";
           
              if ($row['flight_remainingseats']) {
              echo '<td>
                    <form  method = "POST" action = "input1.php">
                     <input class = "button" type="submit" value = "PURCHASE"   />
                      <input name = "id_flight" type = "hidden" value = ' . $row['flight_id'] . ' />
                     </form>
                  </td>';
                }
              else{
                echo '<td>
                    <input class = "disabled" type="submit"  value = "NOT AVAILABLE"/>
                  </td>';
              }
              

              if (3 <= $row['flight_popularity']){
                  echo '<td>
                    <img src="red_arrow.png" width="20" height="20"/>
                  </td>';

              }
              elseif (1 <= $row['flight_popularity']) {
                 echo '<td>
                    <img src="yellow_arrow.png" width="20" height="20"/>
                  </td>';

              }

              else {
                echo '<td>
                    <img src="green_arrow.png" width="20" height="20" />
                  </td>';
              }


              echo "</tr>";
          }

        echo " </tbody></table>";

  mysqli_close($db);

}


?>



<script src="js/main.js"></script>


</body>
</html>