<?php 

// Start the session
session_start();

include_once "config.php";
include('usersignin.php');

if (isset($_SESSION['user']) || isset($_SESSION['admin']))
{
  echo 
  "<div class='modal' id='modalError' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
              <h5 class='modal-title text-center'>You are not allowed here.</h5>
              <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
              </button>
            </div>
            <div class='modal-body'>
              <p>You are being redirected to main page.</p>
            </div>
            <div class='modal-footer'>
              <button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
            </div>
        </div>
      </div>
  </div>";
}


if (isset($_GET['msg']))
{
	echo 
	"<div class='modal' id='myModal' tabindex='-1' role='dialog'>
  		<div class='modal-dialog' role='document'>
   			<div class='modal-content'>
      			<div class='modal-header'>
        			<h5 class='modal-title text-center'>Welcome to IDK Airlines family!</h5>
        			<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          				<span aria-hidden='true'>&times;</span>
        			</button>
      			</div>
      			<div class='modal-body'>
       				<p>" . urldecode($_GET['msg']) . "</p>
       				<p>Please sign in to take advantage of our special campaigns!</p>
      			</div>
      			<div class='modal-footer'>
        			<button type='button' class='btn btn-secondary' data-dismiss='modal'>OK</button>
      			</div>
    		</div>
  		</div>
	</div>";
}

?>

<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="login.css">
	<title>Login Page</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <a class="navbar-brand" id="x" href="main.php">IDK Airlines</a>
	</nav>
	<div class="container">
		<form action="login.php" method="POST">
			<div class="row">
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="card">			
						<div class="card-header">Login</div>
	  					<div class="card-body">
							<form>
								<div class="input-group form-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="fas fa-user"></i></span>
									</div>
									<input type="text" class="form-control" name="username" placeholder="username">		
								</div>
								<div class="input-group form-group">
									<div class="input-group-prepend">
										<span class="input-group-text"><i class="fas fa-key"></i></span>
									</div>
									<input type="password" class="form-control" name="pass" placeholder="password">
								</div>
								<?php if (isset($error)): ?>
								<div class="text-danger text-center"><?php echo $error; ?></div>
								<?php endif; ?>  
								<div class="d-flex flex-row-reverse bd-highlight">
									<button name="login" type="submit" class="btn btn-outline-primary">Sign In</button>
								</div>
							</form>
						</div>
						<div class="card text-center">
						<br>
    						<a href="signup.php">Not an IDK member yet? Click to join our family!</a><br>
    						<a href="forgotpassword.php">Forgot your password?</a><br>
    					</div>
					</div>
				</div>

			</div>
		</form>
	</div>
	<script type="text/javascript">
        $(document).ready(function() {
            $('#myModal').modal('show');
        });

		$(document).ready(function() {
    		$('#modalError').modal('show');
		});

		$("#redirectButton").click(function() {
			window.location.href = "main.php";
		});
    </script>
</body>
</html>