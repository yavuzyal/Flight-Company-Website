<?php 

session_start();

if (!isset($_SESSION["candidate_user"]))
{
	echo 
	"<div class='modal' id='myModal' tabindex='-1' role='dialog'>
  		<div class='modal-dialog' role='document'>
   			<div class='modal-content'>
      			<div class='modal-header'>
        			<h5 class='modal-title text-center'>You are not allowed here.</h5>
        			<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          				<span aria-hidden='true'>&times;</span>
        			</button>
      			</div>
      			<div class='modal-body'>
       				<p>You are being redirected to main page.</p>
      			</div>
      			<div class='modal-footer'>
        			<button type='button' class='btn btn-secondary' id='redirectButton' data-dismiss='modal'>OK</button>
      			</div>
    		</div>
  		</div>
	</div>";
}

include_once "config.php";
include ("updatepassword.php");

?>

<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
	
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>


    <style type="text/css">
    	.navbar-brand {
			font-family: 'Dancing Script', cursive;
  			font-size: 25px;
  			margin-left: 1rem;
		}
		.nav-item {
			margin-right: 20px;
		}
    </style>

	<title>Change Password</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	  <a class="navbar-brand" href="main.php">IDK Airlines</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#userActions" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="userActions">
	    <ul class="navbar-nav ml-auto">
	    	<li class="nav-item">
		        <a class="nav-link mr-3" id="signup" style="color: #fff" href="signup.php">Sign Up
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 2 16 16">
					  <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
					  <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
					</svg>
				</a>
	    	</li>
	    	<li class="nav-item">
		        <a class="nav-link mr-3" style="color: #fff" href="login.php">Login
			        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 2 16 16">
					  <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
					</svg>
				</a>
	    	</li>
	    </ul>
	  </div>
	</nav>

	<div class="container-fluid justify-content-center mt-5">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 ml-sm-auto">
				<h2 class="display-5 text-center">Change Password</h2>
				<p class="lead  text-center">
 		 		Change your password below, but try to not forget it again!
				</p>
				<form id='passForm' action='changepassword.php' method='POST'>
					<input type="hidden" id="hiddenContinue" name="changePassword">
					<div class="form row mt-5" style="margin-left: 6.5rem;">
				        <div class="form-group col-md-10" >
				          <label for="inputNewPass" class="col-form-label">Enter your new password</label>
				          <input type="password" class="form-control" name="newPassword" id="inputNewPass" required>
				        </div>
				        <div id="passwordValidation" class="text-danger" style="display: none;">
				        Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters
				    	</div>  
				    </div>
				    <div class="form row mt-2" style="margin-left: 6.5rem;">
				        <div class="form-group col-md-10">
				          <label for="inputConfirm" class="col-form-label">Confirm your new password</label>
				            <input type="password" class="form-control" id="inputConfirm" required>
				        </div>
				    </div>
				    <div id="passwordConfirm" class="text-danger text-center" style="display: none;">
                    Passwords do not match. Try again.
                  	</div>
                  	<?php if (isset($error)): ?>
                  		<div class="text-danger ml-1 mt-n1">
                    		<?php echo $error; ?>
                  		</div>
                  	<?php endif; ?>
				    <div class="form row justify-content-center mt-3">
  						<button type="button" name="continue" id="buttonContinue" class="btn btn-primary">Continue</button>
  					</div>
				</form>
			</div>
			<div class="col-md-3"></div>	
		</div>
	</div>


	<script type="text/javascript">
		$(document).ready(function() {
            $('#myModal').modal('show');
        });

		$("#redirectButton").click(function() {
			window.location.href = "main.php";
		});

		$("#buttonContinue").click(function () {
			var upperCase= new RegExp('[A-Z]');
			var lowerCase= new RegExp('[a-z]');
			var numbers = new RegExp('[0-9]');

			if ($("#inputNewPass").val() != $("#inputConfirm").val())
			{	
				$("#passwordValidation").hide();	
				$("#inputNewPass").addClass("is-invalid");
				$("#inputConfirm").addClass("is-invalid");
				$("#passwordConfirm").show();
			}

			else if (!($("#inputNewPass").val().match(upperCase) 
					&& $("#inputNewPass").val().match(lowerCase) 
					&& $("#inputNewPass").val().match(numbers) && $("#inputNewPass").val().length >= 8))
			{

				$("#passwordConfirm").hide();
				$("#inputNewPass").addClass("is-invalid");
		        $("#inputConfirm").removeClass("is-invalid");
				$("#passwordValidation").show();		
			}

			else {
				$("#hiddenContinue").val("1");
				$("#passForm").submit();
			}
		});
	</script>
	


</body>
</html>